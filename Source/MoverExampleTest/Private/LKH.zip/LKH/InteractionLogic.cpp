#include "InteractionLogic.h"
#include "GameFramework/Character.h"
#include "Kismet/GameplayStatics.h"
#include "PhysicsEngine/RadialForceComponent.h"
#include "Components/PrimitiveComponent.h"
// #include "PlayerCarryComponent.h" // 실제 구현 시 필요

UInteractionLogic::UInteractionLogic()
{
	InteractionDuration = 2.0f;
	MaxWorkers = 1;
	RadialImpulseStrength = 500.0f; // 적당한 기본 타격감
	RadialImpulseRadius = 200.0f;
	InteractionPromptText = FText::FromString(TEXT("Interact"));
}

FPrimaryAssetId UInteractionLogic::GetPrimaryAssetId() const
{
	return FPrimaryAssetId(TEXT("InteractionLogic"), GetFName());
}

bool UInteractionLogic::CanInteract_Implementation(const ACharacter* User, const AActor* Target) const
{
	if (!User || !Target) return false;

	// 태그 요구사항이 없으면 누구나 가능
	if (RequiredToolTags.IsEmpty())
	{
		return true;
	}

	// [설계] User의 태그(들고 있는 아이템이 부여한 태그)를 확인
	// 실제 구현 시: UPlayerCarryComponent나 Character의 Tags를 조회해야 함.
	// 여기서는 Character의 ActorTags를 예시로 사용.
	/* // 예시 코드:
	   if (const IGameplayTagAssetInterface* TagOwner = Cast<IGameplayTagAssetInterface>(User))
	   {
		   return TagOwner->HasAnyMatchingGameplayTags(RequiredToolTags);
	   }
	*/

	// 임시: 캐릭터의 태그가 하나라도 일치하는지 확인 (간단 검사)
	// (실제 프로젝트에서는 GameplayAbilitySystem이나 별도 컴포넌트 사용 권장)
	return true;
}

void UInteractionLogic::OnInteractComplete_Implementation(ACharacter* User, AActor* Target)
{
	if (!Target || !Target->GetWorld()) return;

	// 1. 완료 사운드 재생
	if (SFX_Complete)
	{
		UGameplayStatics::PlaySoundAtLocation(Target, SFX_Complete, Target->GetActorLocation());
	}

	// 2. 완료 이펙트 재생
	if (VFX_Complete)
	{
		// UNiagaraFunctionLibrary::SpawnSystemAtLocation(...); // 나이아가라 모듈 필요
	}

	// 3. [보완계획서 5-A] 임팩트 물리 (Juice)
	// 성공 시 주변의 가벼운 물체들이 '움찔'하게 만듦
	if (RadialImpulseStrength > 0.0f)
	{
		TArray<TEnumAsByte<EObjectTypeQuery>> ObjectTypes;
		ObjectTypes.Add(UEngineTypes::ConvertToObjectType(ECollisionChannel::ECC_PhysicsBody));

		TArray<AActor*> ActorsToIgnore;
		ActorsToIgnore.Add(Target); // 작업대는 흔들리지 않음
		ActorsToIgnore.Add(User);   // 플레이어도 제외

		UGameplayStatics::ApplyRadialDamageWithFalloff(
			Target,
			0.0f, // 데미지는 0
			0.0f,
			Target->GetActorLocation(),
			RadialImpulseRadius,
			RadialImpulseRadius,
			RadialImpulseStrength,
			nullptr,
			ActorsToIgnore,
			Target,
			nullptr,
			ECollisionChannel::ECC_Visibility
		);

		// 주석: ApplyRadialDamage 대신 AddRadialImpulse를 수동으로 루프 돌며 주는 방식이 
		// 물리 객체 전용으로는 더 깔끔할 수 있음. 위 코드는 범용적인 예시.
	}

	// 4. 구체적인 결과물 스폰 로직은 Blueprint Child에서 구현 (예: 양파 파괴 -> 양파 조각 스폰)
}

void UInteractionLogic::OnInteractTick_Implementation(ACharacter* User, AActor* Target, float DeltaTime, float CurrentProgress)
{
	// 기본적으로는 아무것도 안 함 (블루프린트에서 필요 시 구현)
}