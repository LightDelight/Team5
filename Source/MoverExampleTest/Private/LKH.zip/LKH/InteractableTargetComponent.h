// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "InteractableTargetComponent.generated.h"

class UInteractionLogic;
class ACharacter;
class UWidgetComponent;
class UInteractionProgressWidget;

/** 진행률 변경 시 UI 업데이트를 위한 델리게이트 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnInteractionProgressChanged, float, NewProgress, bool, bIsActive);

/** 작업 완료 시 Owner Actor에게 알림 */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnInteractionCompleted, ACharacter*, Completer, UInteractionLogic*, Logic);

/**
 * [설계서 제3기둥] 상호작용 대상 컴포넌트
 * - 모든 상호작용 가능한 물체(도마, 싱크대, 아이템 등)에 부착됩니다.
 * - 현재 작업 진행도(Progress)와 참여자(Workers)를 관리합니다.
 * - UInteractionLogic(두뇌)에 의존하여 규칙을 수행합니다.
 */
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class UInteractableTargetComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UInteractableTargetComponent();

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

#pragma region Logic & State
protected:
	/** 현재 적용된 상호작용 로직 (전략 패턴) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Logic", Replicated)
	TObjectPtr<UInteractionLogic> CurrentLogic;

	/** 현재 작업 진행률 (0.0 ~ 1.0) */
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "State", ReplicatedUsing = OnRep_CurrentProgress)
	float CurrentProgress;

	/** 현재 작업 중인 플레이어 목록 (협동 계산용) */
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "State", Replicated)
	TArray<TObjectPtr<ACharacter>> ActiveWorkers;

public:
	/**
	 * [로직 스와핑] 런타임에 상호작용 규칙 교체
	 * 예: 도마 위에 양파가 올라오면 'Null' -> 'Chop' 로직으로 변경
	 */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Logic")
	void SetCurrentLogic(UInteractionLogic* NewLogic);

	UFUNCTION(BlueprintPure, Category = "Logic")
	UInteractionLogic* GetCurrentLogic() const { return CurrentLogic; }

	UFUNCTION(BlueprintPure, Category = "Logic")
	float GetCurrentProgress() const { return CurrentProgress; }
	
#pragma endregion

#pragma region Interaction Control
public:
	/**
	 * 플레이어가 E키를 눌러 작업 시작 요청 (서버)
	 * @return true면 시작 성공 (참여자 등록됨)
	 */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Interaction")
	bool BeginInteract(ACharacter* User);

	/** 플레이어가 E키를 떼거나 멀어져서 중단 요청 (서버) */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Interaction")
	void EndInteract(ACharacter* User);

	/** 강제로 진행도 초기화 (아이템 회수 등 상황 발생 시) */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Interaction")
	void ResetProgress();

private:
	/** 작업 완료 처리 (서버) */
	void FinishInteraction();

#pragma endregion

#pragma region UI & Delegates
public:
	/** UI 업데이트용 델리게이트 (BlueprintAssignble) */
	UPROPERTY(BlueprintAssignable, Category = "Events")
	FOnInteractionProgressChanged OnProgressChanged;

	/** 작업 완료 이벤트 */
	UPROPERTY(BlueprintAssignable, Category = "Events")
	FOnInteractionCompleted OnInteractionCompleted;
	
	/** [UI] 작업 진행바 */
	UPROPERTY(EditAnywhere, Category = "UI", Replicated)
	TSubclassOf<UInteractionProgressWidget> ProgressWidgetClass;
	
	/** [UI] 진행바 위치 오프셋 */
	UPROPERTY(EditAnywhere, Category = "UI")
	FVector WidgetOffset = FVector(0, 0, 100);


protected:
	UFUNCTION()
	void OnRep_CurrentProgress();

	/** 로직 에셋 유효성 검사 헬퍼 */
	bool IsLogicValid() const;
	
	UPROPERTY()
	UWidgetComponent* InteractionWidgetComp;
	
	void InitializeWidgetComponent();
	
	void UpdateWidgetComponent();

#pragma endregion
};