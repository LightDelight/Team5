#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ItemBase.h"
#include "SpillManager.h" // ASpillManager 참조를 위해 필요
#include "CartInventoryComponent.generated.h"

UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class UCartInventoryComponent : public UActorComponent
{
    GENERATED_BODY()
};