// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Blueprint/UserWidget.h"
#include "InteractionProgressWidget.generated.h"

class UProgressBar;
class UTextBlock;

/**
 * [UI 베이스] 상호작용 진행바 위젯
 * - 서버의 값을 부드럽게 보간(Interp)하여 보여줍니다.
 * - Blueprint에서는 'BP_OnUpdateVisuals'만 구현하면 됩니다.
 */
UCLASS()
class UInteractionProgressWidget : public UUserWidget
{
	GENERATED_BODY()

public:
	virtual void NativeTick(const FGeometry& MyGeometry, float InDeltaTime) override;

protected:
	/** 서버에서 목표로 하는 실제 진행률 (0.0 ~ 1.0) */
	float TargetProgress;

	/** 화면에 보여지고 있는 현재 진행률 (보간됨) */
	UPROPERTY(BlueprintReadOnly, Category = "Progress")
	float DisplayProgress;

	/** 보간 속도 (높을수록 빠릿함) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	float InterpSpeed = 10.0f;

public:
	/** * 외부(Actor)에서 진행률 업데이트 요청
	 * @param NewProgress 서버 실제 값
	 */
	UFUNCTION(BlueprintCallable, Category = "Progress")
	void UpdateTargetProgress(float NewProgress);

protected:
	/**
	 * [블루프린트 구현용] 시각적 요소 업데이트
	 * - Tick에서 보간된 DisplayProgress 값이 변경될 때마다 호출됩니다.
	 * - BP에서 ProgressBar->SetPercent(DisplayProgress) 등을 연결하세요.
	 */
	UFUNCTION(BlueprintImplementableEvent, Category = "Progress")
	void BP_OnUpdateVisuals(float CurrentValue);
};