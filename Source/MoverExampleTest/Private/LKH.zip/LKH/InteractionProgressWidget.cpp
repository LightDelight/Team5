#include "InteractionProgressWidget.h"
#include "Kismet/KismetMathLibrary.h"

void UInteractionProgressWidget::NativeTick(const FGeometry& MyGeometry, float InDeltaTime)
{
	Super::NativeTick(MyGeometry, InDeltaTime);

	// 목표 값과 현재 값이 거의 비슷하면 연산 중단 (최적화)
	if (FMath::IsNearlyEqual(DisplayProgress, TargetProgress, 0.001f))
	{
		return;
	}

	// [Juice] 부드러운 보간 (FInterpTo)
	// 서버에서 0.5가 확 들어와도, UI는 0.3 -> 0.35 -> 0.4... 로 부드럽게 차오름
	DisplayProgress = FMath::FInterpTo(DisplayProgress, TargetProgress, InDeltaTime, InterpSpeed);

	// 블루프린트에 시각적 갱신 요청
	BP_OnUpdateVisuals(DisplayProgress);
}

void UInteractionProgressWidget::UpdateTargetProgress(float NewProgress)
{
	TargetProgress = FMath::Clamp(NewProgress, 0.0f, 1.0f);

	// 만약 0이 들어오면(초기화), 보간 없이 즉시 0으로 리셋 (뚝 끊겨야 자연스러움)
	if (TargetProgress <= 0.0f)
	{
		DisplayProgress = 0.0f;
		BP_OnUpdateVisuals(0.0f);
	}
}