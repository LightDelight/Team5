#include "InteractableZoneBase.h"
#include "InteractableTargetComponent.h"
#include "Components/BoxComponent.h"
#include "Components/DecalComponent.h"
#include "Components/WidgetComponent.h"
#include "InteractionProgressWidget.h"

AInteractableZoneBase::AInteractableZoneBase()
{
	PrimaryActorTick.bCanEverTick = false; // 로직은 컴포넌트가 수행하므로 액터 틱은 끔
	bReplicates = true;

	// 1. 충돌체 설정 (Root)
	ZoneCollider = CreateDefaultSubobject<UBoxComponent>(TEXT("ZoneCollider"));
	SetRootComponent(ZoneCollider);
	ZoneCollider->SetBoxExtent(FVector(50.0f, 50.0f, 10.0f));
	ZoneCollider->SetCollisionProfileName(TEXT("BlockAllDynamic")); // Trace에 잡혀야 함

	// 2. 데칼 설정 (시각적 효과)
	ZoneDecal = CreateDefaultSubobject<UDecalComponent>(TEXT("ZoneDecal"));
	ZoneDecal->SetupAttachment(RootComponent);
	ZoneDecal->SetRelativeRotation(FRotator(-90.0f, 0.0f, 0.0f)); // 바닥을 향하도록
	ZoneDecal->DecalSize = FVector(10.0f, 50.0f, 50.0f); // 깊이, 폭, 높이

	// 3. 상호작용 컴포넌트
	InteractableTarget = CreateDefaultSubobject<UInteractableTargetComponent>(TEXT("InteractableTarget"));

	// 4. UI 위젯
	ProgressWidget = CreateDefaultSubobject<UWidgetComponent>(TEXT("ProgressWidget"));
	ProgressWidget->SetupAttachment(RootComponent);
	ProgressWidget->SetWidgetSpace(EWidgetSpace::Screen); // 화면을 바라보도록
	ProgressWidget->SetDrawAtDesiredSize(true);
	ProgressWidget->SetVisibility(false); // 평소엔 숨김
	ProgressWidget->SetRelativeLocation(FVector(0.0f, 0.0f, 50.0f)); // 약간 위에 표시

	bDestroyOnComplete = true;
}

void AInteractableZoneBase::BeginPlay()
{
	Super::BeginPlay();

	// 서버: 로직 할당
	if (HasAuthority() && AssignedLogic)
	{
		InteractableTarget->SetCurrentLogic(AssignedLogic);
	}

	// 클라이언트/서버 공통: 델리게이트 바인딩 (UI 연동)
	if (InteractableTarget)
	{
		InteractableTarget->OnProgressChanged.AddDynamic(this, &AInteractableZoneBase::HandleProgressChanged);
		InteractableTarget->OnInteractionCompleted.AddDynamic(this, &AInteractableZoneBase::HandleInteractionCompleted);
	}
}

void AInteractableZoneBase::HandleProgressChanged(float NewProgress, bool bIsActive)
{
	if (!ProgressWidget) return;

	// 1. 위젯 가시성 제어
	ProgressWidget->SetVisibility(bIsActive);

	// 2. 캐스팅 후 안전하게 함수 호출
	// FindFunction이나 ProcessEvent 같은 복잡한 코드가 사라짐!
	if (UInteractionProgressWidget* MyWidget = Cast<UInteractionProgressWidget>(ProgressWidget->GetUserWidgetObject()))
	{
		MyWidget->UpdateTargetProgress(NewProgress);
	}
}

void AInteractableZoneBase::HandleInteractionCompleted(ACharacter* Completer, UInteractionLogic* Logic)
{
	if (!HasAuthority()) return;

	// 얼룩 닦기 등 일회성 작업이면 액터 파괴
	if (bDestroyOnComplete)
	{
		Destroy();
	}
}