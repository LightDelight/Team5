// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ItemBase.generated.h"

// 전방 선언
class UCapsuleComponent;
class UStaticMeshComponent;
class UItemData;

/**
 * 아이템의 현재 상태 정의
 * 설계서 제1기둥: 상태 머신 (EItemState) 반영
 */
UENUM(BlueprintType)
enum class EItemState : uint8
{
	Basic       UMETA(DisplayName = "Basic (Physical)"),   // 기본 물리 상태
	Held        UMETA(DisplayName = "Held"),               // 플레이어 손에 들림
	Throwing    UMETA(DisplayName = "Throwing"),           // 던져지는 중
	Spilled     UMETA(DisplayName = "Spilled"),            // 쏟아짐 (물리 멈춤)
	InSlot      UMETA(DisplayName = "InSlot")              // 진열대/작업대 슬롯 장착
};

UCLASS()
class AItemBase : public AActor
{
	GENERATED_BODY()
	
public:	
	AItemBase();

protected:
	virtual void BeginPlay() override;
	virtual void Tick(float DeltaTime) override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

#pragma region Components
protected:
	/** * [서버 논리적 충돌체]
	 * 실제 물리 연산과 충돌 처리를 담당하는 루트 컴포넌트입니다.
	 * 굴러다니는 것을 방지하기 위해 Capsule을 사용합니다.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UCapsuleComponent> RootCollider;

	/**
	 * [클라이언트 시각적 메쉬]
	 * 실제 눈에 보이는 메쉬입니다. 루트의 물리 연산을 따라다니며 보간됩니다.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> VisualMesh;
#pragma endregion

#pragma region Data & Properties
public:
	/** 아이템의 정체성 데이터 (이름, 가격, 무게 등) */
	UPROPERTY(EditAnywhere, BlueprintReadWrite, Category = "Data", ReplicatedUsing = OnRep_ItemData)
	TObjectPtr<UItemData> ItemData;

protected:
	/** 현재 아이템 상태 (RepNotify로 시각적/물리적 상태 동기화) */
	UPROPERTY(ReplicatedUsing = OnRep_ItemState, VisibleInstanceOnly, Category = "State")
	EItemState CurrentState;

	/** * [멀티플레이 안정성] 소유권 뮤텍스 
	 * 설계서 제5기둥 A: 동시 집기 방지 (Race Condition Handling)
	 * true면 서버에서 누군가 집기 처리를 시작한 상태입니다.
	 */
	UPROPERTY(Replicated, VisibleInstanceOnly, Category = "Network")
	bool bIsLockedForGrab;

#pragma endregion

#pragma region Functions
public:
	/**
	 * 누군가 이 아이템을 집으려 할 때 호출 (서버 전용)
	 * @return true면 소유권 획득 성공, false면 이미 잠김(실패)
	 */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Interaction")
	bool AttemptGrabMutex();

	/** 집기 실패 시 잠금 해제 (서버 전용) */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Interaction")
	void ReleaseMutex();

	/** 상태 변경 요청 (서버 전용) */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "State")
	void SetItemState(EItemState NewState);

protected:
	/** 상태 변경 시 클라이언트에서 물리/시각 효과 동기화 */
	UFUNCTION()
	void OnRep_ItemState();

	/** 물리 설정 적용 (상태에 따라 켜고 끄기) */
	void UpdatePhysicsConstraint();

	/** * [VInterp 보간]
	 * 클라이언트에서 메쉬가 루트를 부드럽게 따라가게 하는 로직
	 */
	void SmoothVisualInterpolation(float DeltaTime);
	
	/** [추가됨] ItemData가 복제되었을 때 호출 */
	UFUNCTION()
	void OnRep_ItemData();

	/** [추가됨] 실제 데이터를 액터에 적용하는 핵심 함수 */
	void ApplyItemData();
	
	/** [추가됨] 에디터에서 값 변경 시 실시간 반영 (Construction Script 대용) */
	virtual void OnConstruction(const FTransform& Transform) override;

#pragma endregion
};