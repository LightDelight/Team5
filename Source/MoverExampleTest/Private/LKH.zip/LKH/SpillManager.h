#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ItemBase.h"
#include "InteractableTargetComponent.h" // 컴포넌트 헤더
#include "SpillManager.generated.h"

UCLASS()
class ASpillManager : public AActor
{
    GENERATED_BODY()
};