// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h"
#include "InteractionLogic.generated.h"

class ACharacter;
class AActor;
class USoundBase;
class UParticleSystem;
class UNiagaraSystem;

/**
 * [설계서 제3기둥] 작업 지침서 (Strategy Pattern)
 * 상호작용의 "규칙, 조건, 결과"를 정의하는 에셋입니다.
 * AWorkstation이나 InteractableTargetComponent는 이 로직을 갈아끼우며 행동이 변합니다.
 */
UCLASS(Blueprintable, BlueprintType)
class UInteractionLogic : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	UInteractionLogic();

	virtual FPrimaryAssetId GetPrimaryAssetId() const override;

#pragma region 1. Rules & Conditions (규칙)
public:
	/** 작업 소요 시간 (초). 0이면 즉시 완료. */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Rules", meta = (ClampMin = "0.0"))
	float InteractionDuration;

	/** * 필요한 도구 태그
	 * 예: Tool.Knife (칼을 들고 있어야 썰기 가능)
	 * 비어있으면 맨손으로 가능.
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Rules")
	FGameplayTagContainer RequiredToolTags;

	/**
	 * 플레이어가 취해야 할 애니메이션 태그
	 * 예: Action.Chop (칼질 모션), Action.Scrub (문지르기)
	 * InteractManager가 이 태그를 보고 몽타주 섹션을 결정합니다.
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Rules")
	FGameplayTag RequiredActionTag;

	/** 최대 협동 가능 인원 (속도 부스팅용) */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Rules", meta = (ClampMin = "1"))
	int32 MaxWorkers;

	/** UI에 표시할 텍스트 (예: "썰기", "설거지") */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Rules")
	FText InteractionPromptText;
#pragma endregion

#pragma region 2. Feedback (시청각 연출)
public:
	// --- 작업 중 (Loop) ---

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Feedback|Loop")
	TObjectPtr<USoundBase> SFX_WorkLoop;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Feedback|Loop")
	TObjectPtr<UNiagaraSystem> VFX_WorkLoop;

	// --- 완료 시 (Complete) ---

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Feedback|Complete")
	TObjectPtr<USoundBase> SFX_Complete;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Feedback|Complete")
	TObjectPtr<UNiagaraSystem> VFX_Complete;

	/** * [보완계획서 5-A] 임팩트 물리 세기
	 * 완료 시 주변 물체에 가할 충격량 (0이면 비활성)
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Feedback|Physics")
	float RadialImpulseStrength;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Feedback|Physics")
	float RadialImpulseRadius;
#pragma endregion

#pragma region 3. Logic Methods (행동)
public:
	/**
	 * 상호작용 가능 여부 검사 (태그 검사 등)
	 * @param User 요청한 플레이어 캐릭터
	 * @param Target 상호작용 대상 (도마, 싱크대 등)
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Logic")
	bool CanInteract(const ACharacter* User, const AActor* Target) const;

	/**
	 * 상호작용 완료 시 호출 (결과 처리)
	 * Blueprint에서 오버라이드하여 아이템 스폰 등을 구현합니다.
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Logic")
	void OnInteractComplete(ACharacter* User, AActor* Target);

	/**
	 * 상호작용 진행 중 매 틱 호출 (선택 사항)
	 * 게이지 차오르는 동안 특별한 로직이 필요할 때 사용
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Logic")
	void OnInteractTick(ACharacter* User, AActor* Target, float DeltaTime, float CurrentProgress);
#pragma endregion
};