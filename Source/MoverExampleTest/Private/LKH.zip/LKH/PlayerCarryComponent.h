// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "ItemData.h" // EItemGripType 열거형 사용
#include "PlayerCarryComponent.generated.h"

class AItemBase;
class ACharacter;
class USceneComponent;

/** 던지기 예측 궤적 결과 구조체 */
struct FThrowTrajectoryResult
{
	FVector EndLocation;
	AActor* HitActor;
};

/**
 * [설계서 제4기둥] 물류 담당 컴포넌트
 * - 캐릭터에 부착되어 물건을 들고(Pick), 놓고(Put), 던지는(Throw) 물리적 행위를 전담합니다.
 * - InteractManager와 독립적으로 작동합니다.
 */
UCLASS(ClassGroup = (Custom), meta = (BlueprintSpawnableComponent))
class UPlayerCarryComponent : public UActorComponent
{
	GENERATED_BODY()

public:
	UPlayerCarryComponent();

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

#pragma region Configuration
protected:
	/** 아이템을 부착할 소켓 이름 (예: Hand_R) */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	FName HandSocketName;

	/** 아이템 탐색 거리 (cm) */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float ReachDistance;

	/** 기본 던지기 힘 (Velocity) */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float BaseThrowStrength;

	/** 던지기 각도 (Pitch) */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float ThrowPitchAngle;
#pragma endregion

#pragma region State
protected:
	/** 현재 들고 있는 아이템 (Replicated) */
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, ReplicatedUsing = OnRep_HeldItem, Category = "State")
	TObjectPtr<AItemBase> HeldItem;

	/** 현재 잡고 있는 아이템의 그립 타입 (애니메이션 BP용) */
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Replicated, Category = "State")
	EItemGripType CurrentGripType;

	/** [캐싱] 소유자 캐릭터 */
	UPROPERTY()
	TObjectPtr<ACharacter> OwnerCharacter;
#pragma endregion

#pragma region Inputs & Actions
public:
	/**
	 * [입력] 메인 액션 (Spacebar Tap)
	 * - 빈손: 앞에 있는 물건 줍기 or 슬롯에서 꺼내기
	 * - 든손: 앞에 있는 슬롯에 넣기 or (슬롯 없으면) 바닥에 내려놓기
	 */
	UFUNCTION(BlueprintCallable, Category = "Input")
	void Input_MainAction();

	/**
	 * [입력] 던지기 (Spacebar Hold or F key)
	 * - 물건을 전방으로 투척
	 */
	UFUNCTION(BlueprintCallable, Category = "Input")
	void Input_Throw();

	/**
	 * [Swap 지원] 외부(Workstation)에서 강제로 아이템을 쥐여줄 때 호출
	 * 예: 사과를 들고 '사과 박스'와 상호작용 -> 사과는 박스로, 박스에서 '새 사과'가 손으로 교체됨
	 */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Interaction")
	void ForceHoldItem(AItemBase* NewItem);

protected:
	UFUNCTION(Server, Reliable)
	void Server_TryMainAction();

	UFUNCTION(Server, Reliable)
	void Server_TryThrow(FVector ThrowVelocity);

	/** 실제 줍기 로직 (Server) */
	void ExecutePickup(AItemBase* TargetItem);

	/** 실제 놓기/넣기 로직 (Server) */
	void ExecutePlace(AActor* TargetSlotActor);

	/** 실제 던지기 로직 (Server) */
	void ExecuteThrow(FVector Velocity);

	/** 탐색 헬퍼: 전방의 아이템이나 슬롯을 찾음 */
	AActor* ScanForObject(FVector& OutImpactPoint) const;
#pragma endregion

#pragma region Throwing Physics & Auto-Aim
public:
	/**
	 * [클라이언트] 던지기 궤적 예측 및 시각화
	 * - Tick에서 호출하여 Spline Mesh 등을 업데이트
	 * @return 예측된 낙하 지점
	 */
	UFUNCTION(BlueprintCallable, Category = "Physics")
	bool PredictThrowPath(FVector& OutHitLocation, TArray<FVector>& OutPathPoints);

protected:
	/** 오토 에이밍: 던질 궤적 끝에 슬롯(쓰레기통 등)이 있다면 유도 */
	FVector CalculateAutoAimVelocity(const FVector& StartLoc, const FVector& ForwardDir) const;
#pragma endregion

#pragma region Visuals
protected:
	UFUNCTION()
	void OnRep_HeldItem();

	/** 아이템을 손 소켓에 부착 */
	void AttachItemToHand(AItemBase* Item);
#pragma endregion
};