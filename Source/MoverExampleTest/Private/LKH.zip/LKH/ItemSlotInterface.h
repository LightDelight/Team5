// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "UObject/Interface.h"
#include "ItemSlotInterface.generated.h"

class AItemBase;
class ACharacter;

// 언리얼 엔진 리플렉션 시스템용 빈 클래스 (수정 불필요)
UINTERFACE(MinimalAPI, Blueprintable)
class UItemSlotInterface : public UInterface
{
	GENERATED_BODY()
};

/**
 * [설계서 제4기둥] 물류 시스템 슬롯 인터페이스 (Logistics Contract)
 * - 작업대, 진열대, 쓰레기통 등 "아이템을 받아주거나 주는" 모든 객체가 구현해야 합니다.
 * - PlayerCarryComponent는 대상의 구체적인 클래스를 몰라도 이 인터페이스 함수를 호출하여 상호작용합니다.
 */
class IItemSlotInterface
{
	GENERATED_BODY()

public:
	/**
	 * [핵심] 아이템 놓기 시도 (Put / Combine / Swap)
	 * * @param User           요청한 플레이어 (교체 시 아이템을 돌려받을 대상)
	 * @param IncomingItem   놓으려는 아이템 객체
	 * @return               true면 성공(플레이어 손에서 아이템이 떠남), false면 실패(아무 일도 안 일어남)
	 * * [구현 가이드 (Workstation)]
	 * 1. 슬롯이 비었을 때:
	 * - IncomingItem의 소유권을 가져오고 슬롯 위치에 부착.
	 * * 2. 슬롯이 찼을 때 (Occupied):
	 * - 조합(Combine) 검사: (SlotItem + IncomingItem) 레시피가 있는지 확인.
	 * -> 있다면 둘 다 파괴 후 결과물 스폰.
	 * - 조합 불가 시 교체(Swap):
	 * -> SlotItem을 User의 손에 쥐여주고(ForceGrab), IncomingItem을 슬롯에 장착.
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Logistics")
	bool TryPutItem(ACharacter* User, AItemBase* IncomingItem);

	/**
	 * [핵심] 아이템 가져오기 시도 (Take / Spawn)
	 * * @param User  요청한 플레이어
	 * @return      획득한 아이템 포인터 (실패 시 nullptr)
	 * * [구현 가이드]
	 * 1. 일반 가구: 현재 슬롯에 있는 아이템을 Detach하고 반환.
	 * 2. 자판기(Provider): 재고(Stock) 확인 후, 새로운 아이템을 SpawnActor하여 반환.
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Logistics")
	AItemBase* TryTakeItem(ACharacter* User);

	/**
	 * 현재 슬롯에 있는 아이템 조회 (Helper)
	 * - InteractManager나 UI에서 상태를 확인할 때 사용
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Logistics")
	AItemBase* GetSlottedItem() const;

	/**
	 * 슬롯이 비어있는지 확인 (Helper)
	 */
	UFUNCTION(BlueprintNativeEvent, BlueprintCallable, Category = "Logistics")
	bool IsSlotEmpty() const;
};