#include "ProductDisplayBase.h"
#include "ItemBase.h"
#include "ItemData.h"
#include "Components/StaticMeshComponent.h"
#include "Net/UnrealNetwork.h"
#include "Engine/World.h"

AProductDisplayBase::AProductDisplayBase()
{
	PrimaryActorTick.bCanEverTick = false; // 물리/로직 없음, 틱 불필요
	bReplicates = true;

	// 1. 외형 설정
	BodyMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BodyMesh"));
	SetRootComponent(BodyMesh);
	BodyMesh->SetCollisionProfileName(TEXT("BlockAllDynamic"));

	// 2. 고스트 메쉬 설정
	DisplayMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("DisplayMesh"));
	DisplayMesh->SetupAttachment(BodyMesh);
	DisplayMesh->SetCollisionProfileName(TEXT("NoCollision")); // 물리/충돌 완전 제거
	DisplayMesh->SetRelativeLocation(FVector(0.0f, 0.0f, 50.0f));

	CurrentStock = 5;
	MaxStock = 10;
}

void AProductDisplayBase::BeginPlay()
{
	Super::BeginPlay();

	// 초기 시각 상태 동기화
	if (HasAuthority())
	{
		OnRep_ItemToSell();
		OnRep_CurrentStock();
	}
}

void AProductDisplayBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(AProductDisplayBase, ItemToSell);
	DOREPLIFETIME(AProductDisplayBase, CurrentStock);
}

void AProductDisplayBase::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	// 에디터 레벨 배치 시 즉시 메쉬가 보이도록
	OnRep_ItemToSell();
}

#pragma region Visual Updates

void AProductDisplayBase::OnRep_ItemToSell()
{
	if (ItemToSell && ItemToSell->StaticMesh)
	{
		DisplayMesh->SetStaticMesh(ItemToSell->StaticMesh);
		// 아이템 데이터에 스케일 정보가 있다면 적용 가능
	}
	else
	{
		DisplayMesh->SetStaticMesh(nullptr);
	}
}

void AProductDisplayBase::OnRep_CurrentStock()
{
	// 재고가 있으면 보여주고, 없으면 숨김
	bool bHasStock = CurrentStock > 0;
	DisplayMesh->SetVisibility(bHasStock);

	// 심화: 재고량에 따라 쌓여있는 높이를 다르게 하거나(메쉬 여러 개),
	// 머티리얼 파라미터를 변경하는 연출 추가 가능.
}

#pragma endregion

#pragma region IItemSlotInterface Implementation

AItemBase* AProductDisplayBase::TryTakeItem_Implementation(ACharacter* User)
{
	if (!HasAuthority()) return nullptr;

	// 1. 재고 확인
	if (CurrentStock <= 0 || !ItemToSell)
	{
		// 재고 없음 (품절 소리 재생 등 가능)
		return nullptr;
	}

	// 2. 재고 차감
	CurrentStock--;
	OnRep_CurrentStock(); // 서버 시각 업데이트

	// 3. 실제 아이템 스폰 (Spawn Logic)
	// 아이템을 담을 수 있는 ItemBase 클래스(Blueprint)를 스폰해야 함.
	// 일반적으로 ItemData에 연결된 BP 클래스가 있거나, 기본 BP_ItemBase를 사용함.

	// 여기서는 기본 AItemBase를 스폰하고 데이터를 주입하는 방식 사용
	FActorSpawnParameters SpawnParams;
	SpawnParams.SpawnCollisionHandlingOverride = ESpawnActorCollisionHandlingMethod::AlwaysSpawn;

	FVector SpawnLoc = DisplayMesh->GetComponentLocation();
	FRotator SpawnRot = DisplayMesh->GetComponentRotation();

	AItemBase* NewItem = GetWorld()->SpawnActor<AItemBase>(AItemBase::StaticClass(), SpawnLoc, SpawnRot, SpawnParams);

	if (NewItem)
	{
		// 데이터 주입 (중요: 서버에서 설정하면 복제됨)
		NewItem->ItemData = ItemToSell;

		// 강제로 상태 업데이트 (메쉬 적용을 위해)
		// 실제로는 NewItem 내부 OnRep_ItemData가 클라에서 호출되겠지만,
		// 서버 로직 처리를 위해 필요하다면 초기화 함수 호출
	}

	return NewItem;
}

bool AProductDisplayBase::TryPutItem_Implementation(ACharacter* User, AItemBase* IncomingItem)
{
	if (!HasAuthority() || !IncomingItem || !IncomingItem->ItemData) return false;

	// 리필(Restock) 로직

	// 1. 같은 종류의 아이템인지 확인
	if (IncomingItem->ItemData != ItemToSell)
	{
		// 다른 물건은 안 받음 (혹은 진열 상품을 이걸로 교체하는 로직을 짤 수도 있음)
		return false;
	}

	// 2. 재고가 꽉 찼는지 확인
	if (CurrentStock >= MaxStock)
	{
		return false;
	}

	// 3. 재고 증가 및 아이템 흡수
	CurrentStock++;
	OnRep_CurrentStock();

	// 들어온 아이템은 이제 필요 없으므로 파괴 (진열대 안으로 흡수된 연출)
	IncomingItem->Destroy();

	return true;
}

#pragma endregion