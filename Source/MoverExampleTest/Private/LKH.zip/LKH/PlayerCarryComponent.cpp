#include "PlayerCarryComponent.h"
#include "ItemBase.h"
#include "ItemSlotInterface.h"
#include "ItemData.h"
#include "GameFramework/Character.h"
#include "GameFramework/CharacterMovementComponent.h"
#include "Components/PrimitiveComponent.h"
#include "Kismet/GameplayStatics.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Net/UnrealNetwork.h"

UPlayerCarryComponent::UPlayerCarryComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	SetIsReplicated(true);
	HandSocketName = FName("Hand_R");
	ReachDistance = 200.0f; // 2미터
	BaseThrowStrength = 800.0f;
	ThrowPitchAngle = 35.0f;
	CurrentGripType = EItemGripType::None;
}

void UPlayerCarryComponent::BeginPlay()
{
	Super::BeginPlay();
	OwnerCharacter = Cast<ACharacter>(GetOwner());
}

void UPlayerCarryComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);
	DOREPLIFETIME(UPlayerCarryComponent, HeldItem);
	DOREPLIFETIME(UPlayerCarryComponent, CurrentGripType);
}

void UPlayerCarryComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// 클라이언트: 던지기 키를 누르고 있을 때 궤적 그리기 로직 (여기서는 생략, Input_Throw 호출 시 즉발로 가정)
}

#pragma region Inputs

void UPlayerCarryComponent::Input_MainAction()
{
	Server_TryMainAction();
}

void UPlayerCarryComponent::Input_Throw()
{
	if (!HeldItem) return;

	// 클라이언트에서 미리 오토 에이밍 계산을 해서 서버로 보낼 수도 있고,
	// 서버가 카메라 방향을 받아서 계산할 수도 있음. 여기선 서버가 처리하도록 단순화.
	// 정확한 조준을 위해선 클라이언트의 카메라 Forward를 보내는 것이 좋음.
	FVector CameraForward = OwnerCharacter->GetControlRotation().Vector();
	FVector ThrowVel = CalculateAutoAimVelocity(OwnerCharacter->GetActorLocation(), CameraForward);

	Server_TryThrow(ThrowVel);
}

void UPlayerCarryComponent::Server_TryMainAction_Implementation()
{
	FVector ImpactPoint;
	AActor* HitActor = ScanForObject(ImpactPoint);

	// 1. 손이 비었을 때: 줍기 (Pick / Take)
	if (HeldItem == nullptr)
	{
		if (!HitActor) return;

		// A. 슬롯 인터페이스 (자판기, 선반 등)에서 가져오기
		if (HitActor->Implements<UItemSlotInterface>())
		{
			// TryTakeItem 호출
			if (AItemBase* TakenItem = IItemSlotInterface::Execute_TryTakeItem(HitActor, OwnerCharacter))
			{
				ForceHoldItem(TakenItem); // 내 손에 장착
			}
		}
		// B. 바닥에 있는 아이템 줍기
		else if (AItemBase* TargetItem = Cast<AItemBase>(HitActor))
		{
			ExecutePickup(TargetItem);
		}
	}
	// 2. 손에 들었을 때: 놓기 (Put / Place)
	else
	{
		// A. 슬롯에 넣기 (조합/스왑 포함)
		if (HitActor && HitActor->Implements<UItemSlotInterface>())
		{
			ExecutePlace(HitActor);
		}
		// B. 허공/바닥에 내려놓기 (부드러운 Drop)
		else
		{
			// 던지기와 유사하지만 힘을 아주 약하게
			FVector DropVel = OwnerCharacter->GetActorForwardVector() * 100.0f;
			ExecuteThrow(DropVel);
		}
	}
}

void UPlayerCarryComponent::Server_TryThrow_Implementation(FVector ThrowVelocity)
{
	ExecuteThrow(ThrowVelocity);
}

#pragma endregion

#pragma region Logic Core

void UPlayerCarryComponent::ExecutePickup(AItemBase* TargetItem)
{
	if (!TargetItem) return;

	// [설계서 제5기둥 A] Race Condition 방지 (Mutex)
	if (!TargetItem->AttemptGrabMutex())
	{
		// 집기 실패 (다른 플레이어가 선점)
		// Client_PlayFailEffect(); // 필요 시 구현
		return;
	}

	ForceHoldItem(TargetItem);
}

void UPlayerCarryComponent::ForceHoldItem(AItemBase* NewItem)
{
	if (!NewItem) return;

	// 기존 아이템이 있다면 드랍 (Swap 안전장치)
	if (HeldItem)
	{
		ExecuteThrow(OwnerCharacter->GetActorForwardVector() * 100.0f);
	}

	HeldItem = NewItem;
	HeldItem->SetOwner(OwnerCharacter);

	// 태그 부여 (예: 칼을 들면 Tool.Knife 태그 추가)
	if (HeldItem->ItemData)
	{
		// OwnerCharacter->Tags.Append(HeldItem->ItemData->GrantedTags.GetGameplayTagArray()); 
		// 주석: 실제 GameplayTags는 Container 함수 사용 필요. 여기선 단순화.

		// 그립 타입 갱신
		CurrentGripType = HeldItem->ItemData->GripType;
	}

	// 상태 변경 (물리 끄기, 부착 등은 OnRep에서 처리됨)
	HeldItem->SetItemState(EItemState::Held);

	// 서버에서도 부착 수행
	AttachItemToHand(HeldItem);
}

void UPlayerCarryComponent::ExecutePlace(AActor* TargetSlotActor)
{
	if (!HeldItem || !TargetSlotActor) return;

	AItemBase* ItemToPlace = HeldItem;

	// 슬롯에 넣기 시도 (Put / Combine / Swap)
	bool bSuccess = IItemSlotInterface::Execute_TryPutItem(TargetSlotActor, OwnerCharacter, ItemToPlace);

	if (bSuccess)
	{
		// 성공했다면 내 손을 떠난 것임
		// 단, Swap이 발생했다면 TryPutItem 내부에서 ForceHoldItem을 호출해줬거나,
		// 여기서 리턴값을 보고 처리해야 함.
		// WorkstationBase 구현상 Swap 시엔 기존 아이템을 유저에게 Attach하지 않으므로,
		// HeldItem이 여전히 ItemToPlace라면 비워줌.

		if (HeldItem == ItemToPlace)
		{
			HeldItem = nullptr;
			CurrentGripType = EItemGripType::None;

			// 태그 제거 로직 필요
		}
	}
	else
	{
		// 실패 (꽉 찼는데 조합도 안됨 등) -> 피드백 재생
	}
}

void UPlayerCarryComponent::ExecuteThrow(FVector Velocity)
{
	if (!HeldItem) return;

	AItemBase* ThrownItem = HeldItem;

	// 소유권 해제
	HeldItem = nullptr;
	CurrentGripType = EItemGripType::None;
	ThrownItem->SetOwner(nullptr);

	// 물리 활성화 및 투척
	ThrownItem->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
	ThrownItem->SetItemState(EItemState::Throwing); // 여기서 물리가 켜짐

	// 임펄스 적용 (RootCollider)
	if (UPrimitiveComponent* RootPrim = Cast<UPrimitiveComponent>(ThrownItem->GetRootComponent()))
	{
		RootPrim->AddImpulse(Velocity, NAME_None, true); // Velocity change
	}

	// [설계서 2-B] 착지 보정은 ItemBase가 Sleep 상태가 되면 GridManager가 처리함
}

AActor* UPlayerCarryComponent::ScanForObject(FVector& OutImpactPoint) const
{
	if (!OwnerCharacter) return nullptr;

	FVector Start = OwnerCharacter->GetActorLocation();
	FVector Forward = OwnerCharacter->GetActorForwardVector();
	FVector End = Start + (Forward * ReachDistance);

	FHitResult Hit;
	FCollisionQueryParams Params;
	Params.AddIgnoredActor(OwnerCharacter);
	if (HeldItem) Params.AddIgnoredActor(HeldItem);

	// Sphere Sweep으로 넉넉하게 감지
	bool bHit = GetWorld()->SweepSingleByChannel(
		Hit, Start, End, FQuat::Identity,
		ECC_Visibility,
		FCollisionShape::MakeSphere(30.0f),
		Params
	);

	OutImpactPoint = Hit.ImpactPoint;
	return Hit.GetActor();
}

#pragma endregion

#pragma region Auto-Aim & Physics

FVector UPlayerCarryComponent::CalculateAutoAimVelocity(const FVector& StartLoc, const FVector& ForwardDir) const
{
	FVector BaseVelocity = ForwardDir * BaseThrowStrength;
	// 투사체 각도 적용 (위로 살짝)
	BaseVelocity.Z += BaseThrowStrength * FMath::Sin(FMath::DegreesToRadians(ThrowPitchAngle));

	// [설계서 4-B] 오토 에이밍
	// 던질 예상 궤적 끝에 슬롯(IItemSlotInterface)이 있는지 검사
	FPredictProjectilePathParams PredictParams(10.0f, StartLoc, BaseVelocity, 2.0f);
	PredictParams.bTraceWithCollision = true;
	PredictParams.ActorsToIgnore.Add(OwnerCharacter);
	if (HeldItem) PredictParams.ActorsToIgnore.Add(HeldItem);

	FPredictProjectilePathResult PredictResult;
	if (UGameplayStatics::PredictProjectilePath(GetWorld(), PredictParams, PredictResult))
	{
		if (AActor* HitActor = PredictResult.HitResult.GetActor())
		{
			if (HitActor->Implements<UItemSlotInterface>())
			{
				// 목표 슬롯 발견! 정확히 그쪽으로 날아가도록 속도 보정
				FVector TargetLoc = HitActor->GetActorLocation(); // 혹은 슬롯 컴포넌트 위치

				// 포물선 유도 공식 (복잡하므로 여기선 단순 방향 보정)
				FVector DirToTarget = (TargetLoc - StartLoc).GetSafeNormal();
				FVector NewVel = DirToTarget * BaseThrowStrength;
				NewVel.Z = BaseVelocity.Z; // 높이는 유지하여 포물선 그림
				return NewVel;
			}
		}
	}

	return BaseVelocity;
}

bool UPlayerCarryComponent::PredictThrowPath(FVector& OutHitLocation, TArray<FVector>& OutPathPoints)
{
	// 클라이언트에서 궤적 시각화용 (위 로직과 유사하게 구현)
	return false;
}

#pragma endregion

#pragma region Visuals

void UPlayerCarryComponent::OnRep_HeldItem()
{
	if (HeldItem)
	{
		AttachItemToHand(HeldItem);
	}
	else
	{
		// 손에서 아이템이 사라짐 (SetEmpty)
		// 로컬 캐릭터라면 빈손 애니메이션 처리 등
	}
}

void UPlayerCarryComponent::AttachItemToHand(AItemBase* Item)
{
	if (!Item || !OwnerCharacter) return;

	USceneComponent* Mesh = OwnerCharacter->GetMesh();
	FName SocketToUse = HandSocketName;

	// [설계서 6-C] Grip Data 활용
	// 아이템 데이터에 소켓 정보가 있다면 해당 소켓을 기준점으로 잡아야 함
	// (Unreal AttachToComponent는 부모 소켓을 지정하지만, 자식의 오프셋은 RelativeLocation으로 맞춰야 함)
	// 여기서는 단순하게 HandSocketName에 붙이고, ItemData의 오프셋이나 GripSocket을 고려한 로직은 생략됨.

	Item->AttachToComponent(Mesh, FAttachmentTransformRules::SnapToTargetNotIncludingScale, SocketToUse);

	// GripSocketName이 있다면 오프셋 적용 로직 필요
	if (Item->ItemData && !Item->ItemData->GripSocketName.IsNone())
	{
		// 예: ItemMesh->GetSocketTransform(GripSocket)의 역행렬을 곱해서 위치 조정
	}
}

#pragma endregion