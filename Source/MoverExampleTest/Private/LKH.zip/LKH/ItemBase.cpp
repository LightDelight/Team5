#include "ItemBase.h"
#include "Components/CapsuleComponent.h"
#include "Components/StaticMeshComponent.h"
#include "Net/UnrealNetwork.h"
#include "ItemData.h"

AItemBase::AItemBase()
{
	PrimaryActorTick.bCanEverTick = true;
	bReplicates = true;
	SetReplicateMovement(true); // 서버의 위치를 클라이언트에 복제

	// 1. 논리적 루트 (Capsule) 설정
	RootCollider = CreateDefaultSubobject<UCapsuleComponent>(TEXT("RootCollider"));
	SetRootComponent(RootCollider);
	
	// 물리 시뮬레이션 기본 설정
	RootCollider->SetSimulatePhysics(true);
	RootCollider->SetCollisionProfileName(TEXT("PhysicsActor"));
	
	// [설계서 제1기둥] Fake Physics - 안정적인 물리 설정
	// 좌우 회전만 허용하고 X/Y는 잠금
	RootCollider->BodyInstance.bLockXRotation = true; // 회전 방지
	RootCollider->BodyInstance.bLockYRotation = true; // 넘어짐 방지
	
	// 꼬리 끌림 및 미끄러짐 방지를 위한 높은 댐핑
	RootCollider->SetLinearDamping(1.0f);
	RootCollider->SetAngularDamping(2.0f);

	// 2. 시각적 메쉬 (Visual) 설정
	VisualMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("VisualMesh"));
	VisualMesh->SetupAttachment(RootCollider);
	
	// 메쉬는 물리 연산을 하지 않고 루트를 따라다님 (충돌은 Query만 허용하거나 NoCollision)
	VisualMesh->SetSimulatePhysics(false);
	VisualMesh->SetCollisionProfileName(TEXT("NoCollision"));

	// 초기 상태
	CurrentState = EItemState::Basic;
	bIsLockedForGrab = false;
}

void AItemBase::BeginPlay()
{
	Super::BeginPlay();
	UpdatePhysicsConstraint();
}

void AItemBase::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);

	// 클라이언트에서만 시각적 보간 수행 (선택적)
	if (GetNetMode() == NM_Client)
	{
		SmoothVisualInterpolation(DeltaTime);
	}
}

void AItemBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(AItemBase, CurrentState);
	DOREPLIFETIME(AItemBase, ItemData);
	DOREPLIFETIME(AItemBase, bIsLockedForGrab);
}

// [추가됨] 에디터에서 BP의 ItemData를 바꾸면 뷰포트에서 즉시 메쉬가 변함
void AItemBase::OnConstruction(const FTransform& Transform)
{
	Super::OnConstruction(Transform);
	ApplyItemData(); 
}

// [추가됨] 네트워크로 데이터를 받았을 때 호출
void AItemBase::OnRep_ItemData()
{
	ApplyItemData();
}

// [추가됨] 데이터 적용 로직 (핵심)
void AItemBase::ApplyItemData()
{
	if (!ItemData)
	{
		// 데이터가 없으면 메쉬를 비움 (혹은 기본 메쉬)
		if (VisualMesh) VisualMesh->SetStaticMesh(nullptr);
		return;
	}

	// 1. 시각적 메쉬 적용
	if (VisualMesh && ItemData->StaticMesh)
	{
		VisualMesh->SetStaticMesh(ItemData->StaticMesh);
		
		// 아이템마다 크기가 다를 수 있으므로, 캡슐 크기를 메쉬에 맞춰 조정하는 로직을 추가할 수도 있음.
		// 여기서는 단순화를 위해 생략하거나, ItemData에 ColliderRadius 변수를 추가하여 세팅하면 좋음.
	}

	// 2. 물리 속성 적용 (무게)
	if (RootCollider)
	{
		// 무게 설정 (질량 오버라이드 켜기)
		RootCollider->SetMassOverrideInKg(NAME_None, ItemData->Weight, true);

		// 물리 재질 적용 (탄성, 마찰력)
		if (ItemData->PhysicsMaterial)
		{
			RootCollider->SetPhysMaterialOverride(ItemData->PhysicsMaterial);
		}
	}

	// 3. 태그 적용 (선택 사항)
	// 아이템 자체에 태그를 붙여서 Trace로 식별하기 쉽게 함
	// Tags.Add(TEXT("Item"));
}

#pragma region Interaction Logic

bool AItemBase::AttemptGrabMutex()
{
	if (!HasAuthority()) return false;

	// [설계서 제5기둥] Race Condition 방지
	// 이미 잠겨있다면 false 반환 -> 요청자는 Client_GrabFailed 실행
	if (bIsLockedForGrab)
	{
		return false;
	}

	// 잠금 성공
	bIsLockedForGrab = true;
	return true;
}

void AItemBase::ReleaseMutex()
{
	if (!HasAuthority()) return;
	bIsLockedForGrab = false;
}

void AItemBase::SetItemState(EItemState NewState)
{
	if (!HasAuthority()) return;

	CurrentState = NewState;
	
	// 상태 변경 시 즉시 뮤텍스 해제 (상태가 변했다는 건 소유권이 이전되었거나 상황이 끝났음을 의미)
	if (CurrentState != EItemState::Basic)
	{
		bIsLockedForGrab = false; 
	}

	OnRep_ItemState();         // 서버에서도 로직 적용
	UpdatePhysicsConstraint(); // 물리 상태 갱신
}

#pragma endregion

#pragma region Client Visuals

void AItemBase::OnRep_ItemState()
{
	// 상태가 변하면 물리/시각 설정 갱신
	UpdatePhysicsConstraint();
}

void AItemBase::UpdatePhysicsConstraint()
{
	// 상태별 물리 시뮬레이션 제어
	switch (CurrentState)
	{
	case EItemState::Basic:
	case EItemState::Throwing:
		// [물리 ON] 던져지거나 바닥에 있을 때
		RootCollider->SetSimulatePhysics(true);
		RootCollider->SetCollisionEnabled(ECollisionEnabled::QueryAndPhysics);
		// 던질 때는 댐핑을 잠시 줄일 수도 있음 (선택 사항)
		break;

	case EItemState::Held:
	case EItemState::InSlot:
		// [물리 OFF] 잡혀있거나 슬롯에 있을 때
		RootCollider->SetSimulatePhysics(false);
		RootCollider->SetCollisionEnabled(ECollisionEnabled::NoCollision); // 충돌 끔
		break;
		
	case EItemState::Spilled:
		// [물리 OFF] 쏟아져서 바닥에 붙어있을 때 (최적화)
		RootCollider->SetSimulatePhysics(false);
		RootCollider->SetCollisionEnabled(ECollisionEnabled::QueryOnly);
		break;
	}
}

void AItemBase::SmoothVisualInterpolation(float DeltaTime)
{
	// [설계서 제1기둥] VInterp 보간
	// 실제로는 RootComponent가 ReplicatedMovement로 튀면서 이동할 수 있음.
	// VisualMesh가 이를 부드럽게 따라가도록 로직 추가 가능.
	// (기본적으로 SetupAttachment 상태이므로 엔진이 처리하지만, 
	//  더 정교한 Dead Reckoning이 필요하면 Detach 후 직접 보간 코드를 작성)
	
	// 예시: 미세한 흔들림 효과나 래깅 효과 추가
	// FVector TargetLoc = RootCollider->GetComponentLocation();
	// FVector NewLoc = FMath::VInterpTo(VisualMesh->GetComponentLocation(), TargetLoc, DeltaTime, 10.0f);
	// VisualMesh->SetWorldLocation(NewLoc);
}

#pragma endregion