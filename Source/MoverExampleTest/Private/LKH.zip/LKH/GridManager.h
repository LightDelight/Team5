// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "GridManager.generated.h"

/**
 * [설계서 제2기둥] 그리드 매니저
 * - 3D 월드 좌표 대신 2D 정수 그리드(TMap)를 기반으로 객체 위치를 관리합니다.
 * - 물리 연산(Trace)을 최소화하고, 네트워크 동기화 오차를 줄입니다.
 */
UCLASS()
class AGridManager : public AActor
{
	GENERATED_BODY()

public:
	AGridManager();

protected:
	virtual void BeginPlay() override;

public:
	/**
	 * 그리드 셀 크기 (cm 단위)
	 * 설계서 기준: 100cm (1미터)
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	float CellSize;

	/**
	 * 그리드 데이터 저장소
	 * Key: (X, Y) 정수 좌표
	 * Value: 해당 칸을 점유 중인 액터
	 */
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "State")
	TMap<FIntPoint, TObjectPtr<AActor>> GridMap;

#pragma region Coordinate Conversion
public:
	/** 월드 좌표 -> 그리드 좌표 변환 (Round) */
	UFUNCTION(BlueprintPure, Category = "Grid")
	FIntPoint WorldToGrid(const FVector& WorldLocation) const;

	/** 그리드 좌표 -> 월드 좌표 변환 (Center) */
	UFUNCTION(BlueprintPure, Category = "Grid")
	FVector GridToWorld(const FIntPoint& GridPos) const;

	/** 특정 그리드 좌표에 있는 액터 조회 (O(1)) */
	UFUNCTION(BlueprintPure, Category = "Grid")
	AActor* GetActorAtGrid(const FIntPoint& GridPos) const;
#pragma endregion

#pragma region Grid Management
public:
	/**
	 * 액터를 그리드 시스템에 등록 (스폰 시 호출)
	 * @return 등록 성공 여부 (이미 점유된 경우 false 반환 가능)
	 */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Grid")
	bool RegisterActor(AActor* Actor);

	/** 액터 등록 해제 (들거나 파괴 시 호출) */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Grid")
	void UnregisterActor(AActor* Actor);

	/**
	 * [설계서 2-B] 착지 보정 및 밀어내기 (Physics & Snap)
	 * - 아이템이 물리 이동을 멈췄을 때(Sleep) 호출하여 그리드 중앙으로 이동시킴.
	 * - 자리가 차있다면 기존 물체를 밀어냄(Push).
	 */
	UFUNCTION(BlueprintCallable, BlueprintAuthorityOnly, Category = "Grid")
	void SnapActorToGrid(AActor* Actor);

private:
	/** 밀어낼 빈 인접 공간 탐색 (BFS or Simple Neighbor Check) */
	bool FindNearestEmptyNeighbor(const FIntPoint& Center, FIntPoint& OutEmptyPos);

	/** 특정 위치로 액터 강제 이동 (텔레포트 및 맵 갱신) */
	void TeleportActorToGrid(AActor* Actor, const FIntPoint& NewGridPos);

#pragma endregion

#pragma region Debugging
public:
	/** [설계서 7-A] 그리드 비주얼라이저 (치트키용) */
	UFUNCTION(BlueprintCallable, Category = "Debug")
	void ToggleDebugGrid();

protected:
	bool bShowDebugGrid;
	void DrawDebugGrid();
	virtual void Tick(float DeltaTime) override;
#pragma endregion
};