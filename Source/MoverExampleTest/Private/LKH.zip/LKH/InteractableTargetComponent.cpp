#include "InteractableTargetComponent.h"
#include "InteractionLogic.h"
#include "Net/UnrealNetwork.h"
#include "GameFramework/Character.h"
#include "Components/WidgetComponent.h"
#include "InteractionProgressWidget.h"

UInteractableTargetComponent::UInteractableTargetComponent()
{
	PrimaryComponentTick.bCanEverTick = true;
	SetIsReplicated(true);
	CurrentProgress = 0.5f;
}

void UInteractableTargetComponent::BeginPlay()
{
	Super::BeginPlay();
	
	// 안전장치: 시작 시 로직이 없다면 진행 불가
	if (!CurrentLogic)
	{
		SetComponentTickEnabled(false);
	}
	
	InitializeWidgetComponent();
}

void UInteractableTargetComponent::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(UInteractableTargetComponent, CurrentLogic);
	DOREPLIFETIME(UInteractableTargetComponent, CurrentProgress);
	DOREPLIFETIME(UInteractableTargetComponent, ActiveWorkers);
}

#pragma region Interaction Core

void UInteractableTargetComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// 서버에서만 로직 처리
	if (GetOwner() && !GetOwner()->HasAuthority()) return;
	
	// 작업자가 없거나 로직이 없으면 리턴
	if (ActiveWorkers.IsEmpty() || !IsLogicValid()) return;

	// 1. 소요 시간이 0이면 즉시 완료 처리 (틱 돌 필요 없음)
	if (CurrentLogic->InteractionDuration <= 0.0f)
	{
		FinishInteraction();
		return;
	}

	// 2. 진행률 증가 공식
	// Progress += (DeltaTime / Duration) * WorkerCount (협동 시 가속)
	float SpeedFactor = 1.0f / CurrentLogic->InteractionDuration;
	float CoOpMultiplier = static_cast<float>(ActiveWorkers.Num()); // 사람 수만큼 빨라짐
	
	float AddedProgress = SpeedFactor * DeltaTime * CoOpMultiplier;
	CurrentProgress = FMath::Clamp(CurrentProgress + AddedProgress, 0.0f, 1.0f);
	
	UpdateWidgetComponent();
	
	// 3. 로직 에셋의 틱 이벤트 호출 (커스텀 효과용)
	// 마지막 작업자를 대표로 넘김
	if (ActiveWorkers.Num() > 0)
	{
		CurrentLogic->OnInteractTick(ActiveWorkers.Last(), GetOwner(), DeltaTime, CurrentProgress);
	}

	// 4. 완료 체크
	if (CurrentProgress >= 1.0f)
	{
		FinishInteraction();
	}
}

bool UInteractableTargetComponent::BeginInteract(ACharacter* User)
{
	if (GetOwner() && !GetOwner()->HasAuthority() || !User || !IsLogicValid()) return false;

	// 이미 참여 중인지 확인
	if (ActiveWorkers.Contains(User)) return true;

	// 최대 인원 제한 확인 (설계서: 협동 규칙)
	if (ActiveWorkers.Num() >= CurrentLogic->MaxWorkers)
	{
		return false; // 이미 꽉 참
	}

	// [설계서 제3기둥] CanInteract 검사
	if (!CurrentLogic->CanInteract(User, GetOwner()))
	{
		return false; // 도구 부족 등 조건 불만족
	}

	// 참여자 등록
	ActiveWorkers.Add(User);
	
	// 틱 활성화 (슬립 상태였다면 깨움)
	SetComponentTickEnabled(true);

	return true;
}

void UInteractableTargetComponent::EndInteract(ACharacter* User)
{
	if (GetOwner() && !GetOwner()->HasAuthority()) return;

	if (ActiveWorkers.Contains(User))
	{
		ActiveWorkers.Remove(User);
	}

	// 작업자가 모두 떠나면 틱 비활성화 (최적화)
	// 단, 진행도는 유지 (나중에 와서 이어서 하기 위함. 초기화를 원하면 ResetProgress 호출 필요)
	if (ActiveWorkers.IsEmpty())
	{
		SetComponentTickEnabled(false);
		
		// [기획 선택] 손을 떼면 게이지가 초기화되어야 한다면 아래 주석 해제
		// ResetProgress(); 
	}
}

void UInteractableTargetComponent::FinishInteraction()
{
	if (GetOwner() && !GetOwner()->HasAuthority() || !IsLogicValid()) return;

	// 1. 로직 에셋의 완료 함수 실행 (사운드, 이펙트, 스폰 등)
	// 마지막 작업자를 기여자로 간주 (협동 시엔 로직에 따라 다를 수 있음)
	ACharacter* Completer = ActiveWorkers.IsEmpty() ? nullptr : ActiveWorkers.Last();
	CurrentLogic->OnInteractComplete(Completer, GetOwner());

	// 2. Actor에게 알림 (블루프린트 연동용)
	OnInteractionCompleted.Broadcast(Completer, CurrentLogic);

	// 3. 상태 초기화
	ResetProgress();
	
	// 4. 모든 작업자 강제 중단 (작업이 끝났으므로 손 떼게 함)
	// 목록을 복사해서 순회 (Remove 방지)
	TArray<ACharacter*> TempWorkers = ActiveWorkers;
	for (ACharacter* Worker : TempWorkers)
	{
		// 실제로는 PlayerController나 InteractManager에 "작업 끝났어"라고 RPC를 보내야 함
		// 여기서는 리스트만 비움. Manager가 Tick에서 Target의 상태를 보고 알아서 끊어야 함.
		EndInteract(Worker);
	}
}

void UInteractableTargetComponent::ResetProgress()
{
	CurrentProgress = 0.0f;
	OnRep_CurrentProgress(); // 서버에서도 델리게이트 호출을 위해
}

void UInteractableTargetComponent::SetCurrentLogic(UInteractionLogic* NewLogic)
{
	if (GetOwner() && !GetOwner()->HasAuthority()) return;

	// 로직이 바뀌면 진행도 초기화
	CurrentLogic = NewLogic;
	ResetProgress();
	ActiveWorkers.Empty(); // 작업 중이던 사람들 강제 하차
}

#pragma endregion

#pragma region UI & Helpers

void UInteractableTargetComponent::OnRep_CurrentProgress()
{
	// UI 위젯 업데이트를 위해 델리게이트 브로드캐스트
	bool bIsInProgress = CurrentProgress > 0.0f && CurrentProgress < 1.0f;
	OnProgressChanged.Broadcast(CurrentProgress, bIsInProgress);
}

bool UInteractableTargetComponent::IsLogicValid() const
{
	return CurrentLogic != nullptr;
}

void UInteractableTargetComponent::InitializeWidgetComponent()
{
	AActor* Owner = GetOwner();
	if (!Owner || !ProgressWidgetClass) return;
	
	// 1. 위젯 컴포넌트 동적 생성
	InteractionWidgetComp = NewObject<UWidgetComponent>(Owner, TEXT("InteractionWidgetComp"));
	
	if (InteractionWidgetComp)
	{
		// 2. 컴포넌트 등록
		InteractionWidgetComp->RegisterComponent();
		
		// 3. 액터의 루트 컴포넌트에 부착
		InteractionWidgetComp->AttachToComponent(Owner->GetRootComponent(), FAttachmentTransformRules::KeepRelativeTransform);
		
		// 4. 위젯 클래스 설정(에디터에서 지정한 BP위젯)
		InteractionWidgetComp->SetWidgetClass(ProgressWidgetClass);
		
		// 5. UI 설정 (스크린 스페이 권장 : 항상 카메라를 바라봄)
		InteractionWidgetComp->SetWidgetSpace(EWidgetSpace::Screen);
		InteractionWidgetComp->SetDrawSize(FVector2D(200.0f, 50.0f));
		
		// 6. 초기에는 숨김
		InteractionWidgetComp->SetVisibility(true);
		
		UInteractionProgressWidget* Widget = Cast<UInteractionProgressWidget>(InteractionWidgetComp);
		if (Widget)
		{
			Widget->UpdateTargetProgress(0.5f);
		}
	}
}

void UInteractableTargetComponent::UpdateWidgetComponent()
{
	if (InteractionWidgetComp && GetCurrentProgress() > 0.0f)
	{
		InteractionWidgetComp->SetVisibility(true);
	}
	
	UInteractionProgressWidget* Widget = Cast<UInteractionProgressWidget>(InteractionWidgetComp);
	if (Widget)
	{
		Widget->UpdateTargetProgress(0.5f);
	}
}

#pragma endregion