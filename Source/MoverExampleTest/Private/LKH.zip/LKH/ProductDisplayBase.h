// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ItemSlotInterface.h"
#include "ProductDisplayBase.generated.h"

class UStaticMeshComponent;
class UItemData;
class AItemBase;

/**
 * [설계서 제6기둥] 상품 진열대 (Vending Machine Pattern)
 * - 실제 아이템 액터(AItemBase)를 보관하지 않고, '데이터(ItemData)'와 '재고(Stock)'만 관리합니다.
 * - 시각적으로는 'Ghost Mesh'를 사용하여 물리 연산 부하를 0으로 만듭니다.
 * - 플레이어가 집기(Take)를 시도하면 그 순간 아이템을 Spawn 해서 줍니다.
 */
UCLASS()
class AProductDisplayBase : public AActor, public IItemSlotInterface
{
	GENERATED_BODY()

public:
	AProductDisplayBase();

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

#pragma region Components
protected:
	/** 진열대 본체 (선반, 박스 등) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> BodyMesh;

	/**
	 * [최적화] 고스트 메쉬 (Ghost Mesh)
	 * - 실제 AItemBase가 아니라, 시각적으로만 존재하는 껍데기입니다.
	 * - 재고가 0이면 숨겨지고, 1 이상이면 보입니다.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> DisplayMesh;
#pragma endregion

#pragma region Data & Stock
protected:
	/** 판매/진열할 아이템 데이터 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, ReplicatedUsing = OnRep_ItemToSell, Category = "Config")
	TObjectPtr<UItemData> ItemToSell;

	/** 현재 재고 수량 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, ReplicatedUsing = OnRep_CurrentStock, Category = "State")
	int32 CurrentStock;

	/** 최대 재고 수량 (UI 표시 및 리필 제한용) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	int32 MaxStock;
#pragma endregion

#pragma region Logic
public:
	/** 데이터 변경 시 고스트 메쉬 업데이트 */
	UFUNCTION()
	void OnRep_ItemToSell();

	/** 재고 변경 시 가시성 업데이트 */
	UFUNCTION()
	void OnRep_CurrentStock();

	/** 에디터에서 값 변경 시 호출 (Construction Script 대용) */
	virtual void OnConstruction(const FTransform& Transform) override;

	/**
	 * 아이템 판매/제공 로직
	 * 재고를 차감하고 새 액터를 스폰해서 반환합니다.
	 */
	virtual AItemBase* TryTakeItem_Implementation(ACharacter* User) override;

	/**
	 * 재고 보충(Restock) 로직
	 * 가져온 아이템이 진열 상품과 같으면 재고를 늘리고 아이템을 파괴(흡수)합니다.
	 */
	virtual bool TryPutItem_Implementation(ACharacter* User, AItemBase* IncomingItem) override;

	// 진열대는 항상 "무언가 있는 것처럼" 보일 수 있지만, 재고가 없으면 빈 것으로 간주
	virtual bool IsSlotEmpty_Implementation() const override { return CurrentStock <= 0; }

	// 실제 슬롯된 액터는 없음 (가짜이므로 nullptr 반환 혹은 임시 처리)
	virtual AItemBase* GetSlottedItem_Implementation() const override { return nullptr; }

#pragma endregion
};