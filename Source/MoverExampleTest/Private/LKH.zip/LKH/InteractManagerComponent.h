// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Components/ActorComponent.h"
#include "InteractManagerComponent.generated.h"

class UInteractableTargetComponent;
class ACharacter;
class UPrimitiveComponent;
class AGridManager;

/** UI 프롬프트 업데이트 델리게이트 (예: "[E] 썰기", "[E] 상호작용 불가") */
DECLARE_DYNAMIC_MULTICAST_DELEGATE_TwoParams(FOnInteractPromptChanged, bool, bIsVisible, FText, PromptText);

/**
 * [설계서 제3기둥] 상호작용 매니저 (Player's Eyes)
 * - 플레이어 캐릭터에 부착됩니다.
 * - 매 프레임 대상을 스캔(Scan)하고, 입력(E키)을 서버로 중계합니다.
 * - 시각적 피드백(Outline)을 제어합니다.
 */
UCLASS( ClassGroup=(Custom), meta=(BlueprintSpawnableComponent) )
class UInteractManagerComponent : public UActorComponent
{
	GENERATED_BODY()

public:	
	UInteractManagerComponent();

protected:
	virtual void BeginPlay() override;
	virtual void TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction) override;

#pragma region Configuration
protected:
	/** 스캔 거리 (cm) */
	UPROPERTY(EditDefaultsOnly, Category = "Config")
	float ScanDistance;

	/** 스캔 반경 (SphereTrace용) */
	UPROPERTY(EditDefaultsOnly, Category = "Config")
	float ScanRadius;

	/** 입력 버퍼링 시간 (초) - 설계서 제5기둥 B */
	UPROPERTY(EditDefaultsOnly, Category = "Config")
	float InputBufferTime;
#pragma endregion

#pragma region State
protected:
	/** 현재 포커싱된 대상 (없으면 nullptr) */
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "State")
	TWeakObjectPtr<UInteractableTargetComponent> FocusedTarget;

	/** 현재 상호작용 중인가? (E키 홀드 중) */
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, Category = "State")
	bool bIsInteracting;

	/** 입력 버퍼 타이머 핸들 */
	FTimerHandle TimerHandle_InputBuffer;

	/** 로컬 플레이어 컨트롤러 캐싱 (UI/입력용) */
	UPROPERTY()
	TObjectPtr<APlayerController> CachedPC;

	/** [캐싱] 월드 그리드 매니저 (있다면 Trace 대신 사용) */
	UPROPERTY()
	TObjectPtr<AGridManager> CachedGridManager;
#pragma endregion

#pragma region Input Handling
public:
	/** 플레이어 입력: 상호작용 시작 (E키 Press) */
	UFUNCTION(BlueprintCallable, Category = "Input")
	void Input_StartInteract();

	/** 플레이어 입력: 상호작용 중단 (E키 Release) */
	UFUNCTION(BlueprintCallable, Category = "Input")
	void Input_StopInteract();

protected:
	/** 서버로 상호작용 요청 */
	UFUNCTION(Server, Reliable)
	void Server_BeginInteract(UInteractableTargetComponent* Target);

	/** 서버로 중단 요청 */
	UFUNCTION(Server, Reliable)
	void Server_EndInteract(UInteractableTargetComponent* Target);

	/** 버퍼링된 입력 처리 */
	void ProcessBufferedInput();
#pragma endregion

#pragma region Scanning & Visuals
protected:
	/** * 전방 탐색 로직 
	 * - 그리드 매니저가 있다면 Grid 조회, 없다면 SphereTrace 수행
	 */
	void PerformInteractionScan();

	/** 대상 변경 시 처리 (Outline, UI) */
	void SetFocusedTarget(UInteractableTargetComponent* NewTarget);

	/** * 아웃라인(Custom Depth) 업데이트 
	 * - Stencil Value: 250(Green), 251(Yellow), 252(Red) 약속
	 */
	void UpdateOutline(AActor* TargetActor, bool bEnable, int32 StencilValue = 0);

	/** 현재 상황에 맞는 아웃라인 색상 결정 */
	int32 DetermineOutlineColor(const UInteractableTargetComponent* Target) const;

public:
	/** UI 업데이트 이벤트 */
	UPROPERTY(BlueprintAssignable, Category = "Events")
	FOnInteractPromptChanged OnPromptChanged;
#pragma endregion
};