#include "InteractManagerComponent.h"
#include "InteractableTargetComponent.h"
#include "InteractionLogic.h"
#include "GridManager.h"
#include "GameFramework/Character.h"
#include "GameFramework/PlayerController.h"
#include "Components/PrimitiveComponent.h"
#include "Kismet/KismetSystemLibrary.h"
#include "Kismet/GameplayStatics.h"
#include "Net/UnrealNetwork.h"

// 아웃라인 스텐실 값 정의 (프로젝트 세팅의 Custom Depth - Stencil 설정 필요)
#define STENCIL_GREEN  0 // 상호작용 가능
#define STENCIL_YELLOW 1 // 운반 가능 (Carry) - 여기선 사용 안 할 수 있음
#define STENCIL_RED    2 // 불가

UInteractManagerComponent::UInteractManagerComponent()
{
	PrimaryComponentTick.bCanEverTick = true;

	ScanDistance = 150.0f; // 1.5미터 앞
	ScanRadius = 40.0f;
	InputBufferTime = 0.15f; // [보완계획서] 0.15초 버퍼링
	bIsInteracting = false;
}

void UInteractManagerComponent::BeginPlay()
{
	Super::BeginPlay();

	// 로컬 플레이어인 경우에만 PC 캐싱 및 스캔 수행
	if (ACharacter* OwnerChar = Cast<ACharacter>(GetOwner()))
	{
		if (OwnerChar->IsLocallyControlled())
		{
			CachedPC = Cast<APlayerController>(OwnerChar->GetController());
			
			// [설계서 v2.0] 그리드 매니저 캐싱 (비용 절감)
			// (주의: GridManager가 게임모드 등에 의해 생성된 후여야 함)
			AActor* FoundActor = UGameplayStatics::GetActorOfClass(GetWorld(), AGridManager::StaticClass());
			CachedGridManager = Cast<AGridManager>(FoundActor);
		}
	}
}

void UInteractManagerComponent::TickComponent(float DeltaTime, ELevelTick TickType, FActorComponentTickFunction* ThisTickFunction)
{
	Super::TickComponent(DeltaTime, TickType, ThisTickFunction);

	// 로컬 컨트롤러가 아니면 스캔 불필요 (서버는 요청만 처리, 다른 클라는 알 필요 없음)
	if (!CachedPC) return;

	PerformInteractionScan();
}

#pragma region Input Handling

void UInteractManagerComponent::Input_StartInteract()
{
	if (GetOwnerRole() == ROLE_SimulatedProxy) return;

	// [보완계획서] 입력 버퍼링
	// 만약 몽타주 재생 중이라 입력이 씹힐 상황 등을 대비해 타이머로 잠시 유예
	// 여기서는 즉시 시도하되, 실패 시 버퍼에 남기는 로직 대신 단순 딜레이 호출로 구현
	
	// 버퍼 타이머 재설정 (연타 방지 겸 버퍼링)
	GetWorld()->GetTimerManager().SetTimer(TimerHandle_InputBuffer, this, &UInteractManagerComponent::ProcessBufferedInput, InputBufferTime, false);
	
	// 즉시 실행 시도
	ProcessBufferedInput();
}

void UInteractManagerComponent::ProcessBufferedInput()
{
	// 포커스된 대상이 없으면 리턴
	if (!FocusedTarget.IsValid()) return;

	// 이미 상호작용 중이면 리턴
	if (bIsInteracting) return;

	// RPC 호출
	bIsInteracting = true;
	Server_BeginInteract(FocusedTarget.Get());
}

void UInteractManagerComponent::Input_StopInteract()
{
	// 버퍼링 취소
	GetWorld()->GetTimerManager().ClearTimer(TimerHandle_InputBuffer);

	if (bIsInteracting)
	{
		bIsInteracting = false;
		// 포커스된 대상이 있든 없든, 마지막으로 상호작용하던 대상에게 종료를 알림
		// (여기서는 단순화를 위해 FocusedTarget이나 캐싱된 마지막 타겟에게 전송)
		if (FocusedTarget.IsValid())
		{
			Server_EndInteract(FocusedTarget.Get());
		}
	}
}

void UInteractManagerComponent::Server_BeginInteract_Implementation(UInteractableTargetComponent* Target)
{
	if (Target)
	{
		ACharacter* User = Cast<ACharacter>(GetOwner());
		Target->BeginInteract(User);
	}
}

void UInteractManagerComponent::Server_EndInteract_Implementation(UInteractableTargetComponent* Target)
{
	if (Target)
	{
		ACharacter* User = Cast<ACharacter>(GetOwner());
		Target->EndInteract(User);
	}
}

#pragma endregion

#pragma region Scanning & Visuals

void UInteractManagerComponent::PerformInteractionScan()
{
	ACharacter* OwnerChar = Cast<ACharacter>(GetOwner());
	if (!OwnerChar) return;

	UInteractableTargetComponent* NewTargetComp = nullptr;

	// [설계서 v2.0] 1. 그리드 매니저 조회 (O(1))
	// 매니저가 존재한다면 물리 연산(Trace)을 건너뛰고 정수 좌표로 즉시 찾습니다.
	if (CachedGridManager)
	{
		FVector Start = OwnerChar->GetActorLocation();
		FVector Forward = OwnerChar->GetActorForwardVector();
		
		// 플레이어 위치에서 스캔 거리만큼 앞쪽 좌표 계산
		FVector CheckPos = Start + (Forward * ScanDistance);

		FIntPoint TargetGridPos = CachedGridManager->WorldToGrid(CheckPos);
		AActor* GridActor = CachedGridManager->GetActorAtGrid(TargetGridPos);

		if (GridActor)
		{
			NewTargetComp = GridActor->FindComponentByClass<UInteractableTargetComponent>();
		}
	}
	// [Fallback] 2. SphereTrace (기존 로직 - 그리드 매니저가 없을 때 안전장치)
	else
	{
		FVector Start = OwnerChar->GetActorLocation();
		FVector Forward = OwnerChar->GetActorForwardVector();
		FVector End = Start + (Forward * ScanDistance);

		FHitResult HitResult;
		FCollisionQueryParams Params;
		Params.AddIgnoredActor(OwnerChar);

		bool bHit = GetWorld()->SweepSingleByChannel(
			HitResult, 
			Start, 
			End, 
			FQuat::Identity, 
			ECC_Visibility, 
			FCollisionShape::MakeSphere(ScanRadius), 
			Params
		);

		if (bHit && HitResult.GetActor())
		{
			// 충돌한 액터에서 TargetComponent 찾기
			NewTargetComp = HitResult.GetActor()->FindComponentByClass<UInteractableTargetComponent>();
		}
	}

	// 대상이 변경되었거나, 같은 대상이라도 상태가 변했을 수 있음
	if (NewTargetComp != FocusedTarget.Get())
	{
		SetFocusedTarget(NewTargetComp);
	}
	else if (FocusedTarget.IsValid()) 
	{
		// 같은 대상이지만 로직/상태가 변해서 색상을 바꿔야 할 수도 있음 (매 프레임 체크는 비효율적일 수 있으나 반응성은 좋음)
		// 최적화를 위해선 TargetComponent의 델리게이트를 활용해야 하지만, 여기선 Tick에서 갱신
		UpdateOutline(FocusedTarget->GetOwner(), true, DetermineOutlineColor(FocusedTarget.Get()));
	}
}

void UInteractManagerComponent::SetFocusedTarget(UInteractableTargetComponent* NewTarget)
{
	// 1. 기존 타겟 정리 (아웃라인 끄기)
	if (FocusedTarget.IsValid())
	{
		UpdateOutline(FocusedTarget->GetOwner(), false);
	}

	FocusedTarget = NewTarget;

	// 2. 새 타겟 설정
	if (FocusedTarget.IsValid())
	{
		// 아웃라인 켜기
		int32 Stencil = DetermineOutlineColor(FocusedTarget.Get());
		UpdateOutline(FocusedTarget->GetOwner(), true, Stencil);

		// UI 프롬프트 업데이트 (예: "[E] 썰기")
		FText Prompt = FText::GetEmpty();
		if (UInteractionLogic* Logic = FocusedTarget->GetCurrentLogic())
		{
			Prompt = Logic->InteractionPromptText;
		}
		OnPromptChanged.Broadcast(true, Prompt);
	}
	else
	{
		// UI 숨김
		OnPromptChanged.Broadcast(false, FText::GetEmpty());
	}
}

void UInteractManagerComponent::UpdateOutline(AActor* TargetActor, bool bEnable, int32 StencilValue)
{
	if (!TargetActor) return;

	// 액터의 모든 메쉬 컴포넌트를 찾아 CustomDepth 설정
	// (최적화를 위해 미리 캐싱하거나, TargetComponent가 메쉬 정보를 가지고 있게 하는 것이 좋음)
	TArray<UPrimitiveComponent*> Components;
	TargetActor->GetComponents(Components);

	for (UPrimitiveComponent* Comp : Components)
	{
		if (Comp->IsA<UStaticMeshComponent>() || Comp->IsA<USkeletalMeshComponent>())
		{
			Comp->SetRenderCustomDepth(bEnable);
			if (bEnable)
			{
				Comp->SetCustomDepthStencilValue(StencilValue);
			}
		}
	}
}

int32 UInteractManagerComponent::DetermineOutlineColor(const UInteractableTargetComponent* Target) const
{
	if (!Target) return STENCIL_RED;

	ACharacter* User = Cast<ACharacter>(GetOwner());
	
	// 로직 유효성 및 조건 검사
	if (UInteractionLogic* Logic = Target->GetCurrentLogic())
	{
		if (Logic->CanInteract(User, Target->GetOwner()))
		{
			return STENCIL_GREEN; // 가능
		}
		else
		{
			return STENCIL_RED; // 조건 불만족 (도구 부족 등)
		}
	}

	return STENCIL_RED; // 로직 없음
}

#pragma endregion