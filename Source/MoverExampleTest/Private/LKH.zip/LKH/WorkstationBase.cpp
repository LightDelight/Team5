#include "WorkstationBase.h"
#include "InteractableTargetComponent.h"
#include "ItemBase.h"
#include "ItemData.h"
#include "InteractionLogic.h"
#include "Components/StaticMeshComponent.h"
#include "Components/SceneComponent.h"
#include "Components/WidgetComponent.h"
#include "Net/UnrealNetwork.h"
#include "GameFramework/Character.h"
#include "InteractionProgressWidget.h"

AWorkstationBase::AWorkstationBase()
{
	PrimaryActorTick.bCanEverTick = false; // 로직은 컴포넌트가 수행
	bReplicates = true;

	// 1. 외형
	BodyMesh = CreateDefaultSubobject<UStaticMeshComponent>(TEXT("BodyMesh"));
	SetRootComponent(BodyMesh);
	BodyMesh->SetCollisionProfileName(TEXT("BlockAllDynamic")); // Trace 감지용

	// 2. 아이템 슬롯 위치
	ItemSlotPoint = CreateDefaultSubobject<USceneComponent>(TEXT("ItemSlotPoint"));
	ItemSlotPoint->SetupAttachment(BodyMesh);
	ItemSlotPoint->SetRelativeLocation(FVector(0.0f, 0.0f, 100.0f)); // 테이블 위 적당한 높이

	// 3. 작업 로직 컴포넌트
	InteractableTarget = CreateDefaultSubobject<UInteractableTargetComponent>(TEXT("InteractableTarget"));

	// 4. UI 위젯
	ProgressWidget = CreateDefaultSubobject<UWidgetComponent>(TEXT("ProgressWidget"));
	ProgressWidget->SetupAttachment(RootComponent);
	ProgressWidget->SetWidgetSpace(EWidgetSpace::Screen);
	ProgressWidget->SetVisibility(false);
	ProgressWidget->SetRelativeLocation(FVector(0.0f, 0.0f, 150.0f));

	StoredItem = nullptr;
}

void AWorkstationBase::BeginPlay()
{
	Super::BeginPlay();

	// UI 델리게이트 연결
	if (InteractableTarget)
	{
		InteractableTarget->OnProgressChanged.AddDynamic(this, &AWorkstationBase::HandleProgressChanged);

		// 초기 로직 설정 (Empty)
		if (HasAuthority())
		{
			RefreshInteractionLogic();
		}
	}
}

void AWorkstationBase::GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const
{
	Super::GetLifetimeReplicatedProps(OutLifetimeProps);

	DOREPLIFETIME(AWorkstationBase, StoredItem);
}

#pragma region Logic Swapping

void AWorkstationBase::RefreshInteractionLogic()
{
	if (!HasAuthority() || !InteractableTarget) return;

	// [설계서 3-B] 로직 스와핑 핵심
	if (StoredItem && StoredItem->ItemData && StoredItem->ItemData->DefaultInteractionLogic)
	{
		// 아이템에 정의된 로직이 있다면 장착 (예: 양파 -> 썰기)
		InteractableTarget->SetCurrentLogic(StoredItem->ItemData->DefaultInteractionLogic);
	}
	else
	{
		// 비어있거나 로직이 없는 아이템이면 기본 로직 (Null or Wait)
		InteractableTarget->SetCurrentLogic(EmptyLogic);
	}
}

void AWorkstationBase::OnRep_StoredItem()
{
	// 클라이언트: 아이템이 갱신되면 시각적으로 슬롯에 부착
	if (StoredItem)
	{
		// 물리 끄고 슬롯에 고정
		StoredItem->SetItemState(EItemState::InSlot);
		StoredItem->AttachToComponent(ItemSlotPoint, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
	}
}

void AWorkstationBase::HandleProgressChanged(float NewProgress, bool bIsActive)
{
	if (!ProgressWidget) return;

	// 1. 위젯 가시성 제어
	ProgressWidget->SetVisibility(true);

	// 2. 캐스팅 후 안전하게 함수 호출
	// FindFunction이나 ProcessEvent 같은 복잡한 코드가 사라짐!
	if (UInteractionProgressWidget* MyWidget = Cast<UInteractionProgressWidget>(ProgressWidget->GetUserWidgetObject()))
	{
		MyWidget->UpdateTargetProgress(NewProgress);
	}
}

#pragma endregion

#pragma region IItemSlotInterface

bool AWorkstationBase::TryPutItem_Implementation(ACharacter* User, AItemBase* IncomingItem)
{
	if (!HasAuthority() || !IncomingItem) return false;

	// Case 1: 이미 아이템이 있는 경우 (조합 or 스왑)
	if (StoredItem)
	{
		// A. 조합(Combine) 시도
		if (UItemData* ResultData = FindCombinationResult(StoredItem->ItemData, IncomingItem->ItemData))
		{
			// 조합 성공 시 로직 (둘 다 파괴 후 결과 스폰)
			// ProcessCombination(StoredItem, IncomingItem); // 구현 생략 (복잡도 방지)
			return true;
		}

		// B. 조합 불가 시 교체(Swap)
		// 내 거(Stored)를 유저에게 주고, 유저 거(Incoming)를 내가 가짐

		// 1. 기존 아이템 분리
		AItemBase* ReturningItem = StoredItem;
		ReturningItem->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

		// 2. 새 아이템 장착
		IncomingItem->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);
		IncomingItem->SetItemState(EItemState::InSlot);
		IncomingItem->AttachToComponent(ItemSlotPoint, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
		IncomingItem->SetOwner(this); // 소유권 이전
		StoredItem = IncomingItem;

		// 3. 로직 갱신 (새 아이템에 맞춰)
		RefreshInteractionLogic();

		// 4. 기존 아이템은 유저가 가져가도록 처리 (User 측 코드에서 Attach 필요, 여기선 리턴값으로 표현 불가하므로 별도 처리 필요)
		// 실제로는 PlayerCarryComponent에게 "이거 가져가"라고 역으로 알려주거나,
		// User가 들고 있던 걸 Drop하고 ReturningItem을 Pickup하게 해야 함.
		// (단순화를 위해 여기서는 Swap 로직이 User 쪽에서 ReturningItem을 핸들링한다고 가정)

		return true;
	}

	// Case 2: 비어있는 경우 (장착)
	StoredItem = IncomingItem;
	StoredItem->SetItemState(EItemState::InSlot); // 물리 끄기
	StoredItem->AttachToComponent(ItemSlotPoint, FAttachmentTransformRules::SnapToTargetNotIncludingScale);
	StoredItem->SetOwner(this);

	// 로직 갱신 (양파가 올라왔으니 썰기 모드로!)
	RefreshInteractionLogic();

	return true;
}

AItemBase* AWorkstationBase::TryTakeItem_Implementation(ACharacter* User)
{
	if (!HasAuthority() || !StoredItem) return nullptr;

	// 진행 중이던 작업 초기화
	InteractableTarget->ResetProgress();

	AItemBase* ItemToReturn = StoredItem;
	StoredItem = nullptr;

	// 아이템 분리 (물리는 켜지 않음, 플레이어가 잡을 것이므로)
	ItemToReturn->DetachFromActor(FDetachmentTransformRules::KeepWorldTransform);

	// 로직 초기화 (Empty)
	RefreshInteractionLogic();

	return ItemToReturn;
}

#pragma endregion

#pragma region Helpers (Placeholders)

UItemData* AWorkstationBase::FindCombinationResult(UItemData* ItemA, UItemData* ItemB) const
{
	// [TODO] DataTable 조회 로직 구현
	// 예: if (ItemA == Bread && ItemB == Meat) return Burger;
	return nullptr;
}

#pragma endregion