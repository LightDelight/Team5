#include "GridManager.h"
#include "DrawDebugHelpers.h"

AGridManager::AGridManager()
{
	PrimaryActorTick.bCanEverTick = true;
	bShowDebugGrid = false;
	CellSize = 100.0f; // 100cm 간격
}

void AGridManager::BeginPlay()
{
	Super::BeginPlay();
	// 최적화: 디버그 모드가 아니면 Tick 끌 수 있음 (여기선 비주얼라이저 때문에 켜둠)
	SetActorTickEnabled(false);
}

void AGridManager::Tick(float DeltaTime)
{
	Super::Tick(DeltaTime);
	if (bShowDebugGrid)
	{
		DrawDebugGrid();
	}
}

#pragma region Coordinate Conversion

FIntPoint AGridManager::WorldToGrid(const FVector& WorldLocation) const
{
	// X, Y 좌표를 셀 크기로 나누어 반올림
	int32 GridX = FMath::RoundToInt(WorldLocation.X / CellSize);
	int32 GridY = FMath::RoundToInt(WorldLocation.Y / CellSize);
	return FIntPoint(GridX, GridY);
}

FVector AGridManager::GridToWorld(const FIntPoint& GridPos) const
{
	// 그리드 중심 좌표 반환
	// Z축은 기본적으로 0이지만, 실제 사용 시엔 Trace로 바닥 높이를 찾거나 액터의 현재 Z를 유지해야 함.
	return FVector(GridPos.X * CellSize, GridPos.Y * CellSize, 50.0f);
}

AActor* AGridManager::GetActorAtGrid(const FIntPoint& GridPos) const
{
	if (const TObjectPtr<AActor>* FoundActor = GridMap.Find(GridPos))
	{
		return FoundActor->Get();
	}
	return nullptr;
}

#pragma endregion

#pragma region Grid Management

bool AGridManager::RegisterActor(AActor* Actor)
{
	if (!Actor) return false;

	FIntPoint GridPos = WorldToGrid(Actor->GetActorLocation());

	// 이미 누군가 있다면? (스폰 겹침 방지)
	if (GridMap.Contains(GridPos))
	{
		// 겹치면 일단 실패 처리하거나, Snap 로직을 태워야 함.
		// 여기선 단순 등록 로직이므로 false 리턴.
		return false;
	}

	GridMap.Add(GridPos, Actor);
	return true;
}

void AGridManager::UnregisterActor(AActor* Actor)
{
	if (!Actor) return;

	// 맵 전체를 순회하며 찾아서 제거 (Actor 포인터 기준)
	// 역참조 맵(Actor -> GridPos)을 하나 더 두면 O(1)로 줄일 수 있음.
	// 현재는 단순화를 위해 순회 (개수가 많지 않으므로 괜찮음)
	for (auto It = GridMap.CreateIterator(); It; ++It)
	{
		if (It.Value() == Actor)
		{
			It.RemoveCurrent();
			return;
		}
	}
}

void AGridManager::SnapActorToGrid(AActor* IncomingActor)
{
	if (!IncomingActor) return;

	// 1. 현재 대략적인 위치 파악
	FIntPoint TargetPos = WorldToGrid(IncomingActor->GetActorLocation());

	// 2. 해당 자리가 비었는지 확인
	AActor* ExistingActor = GetActorAtGrid(TargetPos);

	if (ExistingActor == nullptr || ExistingActor == IncomingActor)
	{
		// 비었거나 자기 자신이 등록된 경우 -> 그대로 확정
		TeleportActorToGrid(IncomingActor, TargetPos);
	}
	else
	{
		// 3. 자리가 찼다면? [설계서 2-B Push Rule]
		// 기존에 있던 놈(ExistingActor)을 밀어낼 것인가? 새로 온 놈(IncomingActor)을 밀어낼 것인가?
		// 설계서: "기존 물체를 인접한 빈 그리드로 밀어냄" -> 연쇄 작용 가능성 있음.
		// 단순화를 위해 "새로 온 놈"을 빈 곳으로 보내거나, 기존 놈을 한 칸 밀어냄.

		// 여기서는 '기존 물체(ExistingActor)'를 밀어내는 로직 구현
		FIntPoint EmptyPos;
		if (FindNearestEmptyNeighbor(TargetPos, EmptyPos))
		{
			// 기존 물체를 빈 곳으로 강제 이동
			TeleportActorToGrid(ExistingActor, EmptyPos);

			// 새 물체를 원래 목표 자리에 등록
			TeleportActorToGrid(IncomingActor, TargetPos);
		}
		else
		{
			// 주변 4방향이 다 꽉 찼음 -> 예외 처리 (그냥 겹쳐두거나 파괴, 혹은 위로 쌓기)
			// 여기선 임시로 제자리에 둠 (Stacking 처리가 없으므로)
			TeleportActorToGrid(IncomingActor, TargetPos);
			// 경고: GridMap 덮어씌움 발생 가능
		}
	}
}

bool AGridManager::FindNearestEmptyNeighbor(const FIntPoint& Center, FIntPoint& OutEmptyPos)
{
	// 상하좌우 4방향 탐색
	const FIntPoint Directions[] = {
		FIntPoint(1, 0), FIntPoint(-1, 0), FIntPoint(0, 1), FIntPoint(0, -1)
	};

	// 1차 인접 (거리 1)
	for (const FIntPoint& Dir : Directions)
	{
		FIntPoint CheckPos = Center + Dir;
		if (!GridMap.Contains(CheckPos))
		{
			OutEmptyPos = CheckPos;
			return true;
		}
	}

	// 필요시 거리 2, 3으로 BFS 확장 가능
	return false;
}

void AGridManager::TeleportActorToGrid(AActor* Actor, const FIntPoint& NewGridPos)
{
	// 1. 기존 맵에서 제거 (혹시 다른 위치에 있었다면)
	UnregisterActor(Actor);

	// 2. 위치 보정 (Z축은 유지)
	FVector NewLocation = GridToWorld(NewGridPos);
	NewLocation.Z = Actor->GetActorLocation().Z; // 높이는 유지

	Actor->SetActorLocation(NewLocation);

	// 3. 맵에 등록
	GridMap.Add(NewGridPos, Actor);

	// 4. 물리 끄기 (선택 사항: 완전히 정착시키려면)
	// UPrimitiveComponent* Root = Cast<UPrimitiveComponent>(Actor->GetRootComponent());
	// if(Root) Root->SetSimulatePhysics(false);
}

#pragma endregion

#pragma region Debugging

void AGridManager::ToggleDebugGrid()
{
	bShowDebugGrid = !bShowDebugGrid;
	SetActorTickEnabled(bShowDebugGrid); // 볼 때만 Tick 켜기
}

void AGridManager::DrawDebugGrid()
{
	if (!GetWorld()) return;

	// 플레이어 주변만 그리기 (최적화)
	FVector Center = GetWorld()->GetFirstPlayerController()->GetPawn()->GetActorLocation();
	FIntPoint CenterGrid = WorldToGrid(Center);
	int32 Range = 5; // 주변 5칸

	for (int32 x = -Range; x <= Range; x++)
	{
		for (int32 y = -Range; y <= Range; y++)
		{
			FIntPoint GridPos = CenterGrid + FIntPoint(x, y);
			FVector WorldPos = GridToWorld(GridPos);

			// 점유 상태에 따라 색상 변경
			FColor DrawColor = GridMap.Contains(GridPos) ? FColor::Red : FColor::Green;

			DrawDebugBox(GetWorld(), WorldPos, FVector(CellSize * 0.45f, CellSize * 0.45f, 5.0f), DrawColor, false, -1.0f, 0, 2.0f);

			// 좌표 텍스트 표시
			// DrawDebugString(GetWorld(), WorldPos, FString::Printf(TEXT("(%d,%d)"), GridPos.X, GridPos.Y), nullptr, FColor::White, 0.0f, true);
		}
	}
}

#pragma endregion