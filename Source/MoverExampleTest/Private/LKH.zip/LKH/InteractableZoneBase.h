// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "InteractableZoneBase.generated.h"

class UInteractableTargetComponent;
class UBoxComponent;
class UDecalComponent;
class UWidgetComponent;
class UInteractionLogic;

/**
 * [설계서 제3기둥] 정적 상호작용 구역 베이스
 * - 형체가 없거나(얼룩, 불), 고정된 위치에서 수행하는 작업(배전반 수리)의 부모 클래스입니다.
 * - 물리적 충돌(Collider)과 작업 로직(TargetComponent)을 가집니다.
 * - IItemSlotInterface는 상속받지 않습니다. (물건을 놓는 곳이 아님)
 */
UCLASS()
class AInteractableZoneBase : public AActor
{
	GENERATED_BODY()

public:
	AInteractableZoneBase();

protected:
	virtual void BeginPlay() override;

#pragma region Components
protected:
	/** * [충돌체] 상호작용 감지용 (InteractManager의 Trace 대상)
	 * - BlockAllDynamic 혹은 Trace 전용 채널 사용
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UBoxComponent> ZoneCollider;

	/** [시각적 표현] 바닥 얼룩 등을 표현하기 위한 데칼 (선택 사항) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UDecalComponent> ZoneDecal;

	/** [두뇌] 실제 작업 진행도 관리 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UInteractableTargetComponent> InteractableTarget;

	/** [UI] 작업 진행바 위젯 (자동 연동) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UWidgetComponent> ProgressWidget;
#pragma endregion

#pragma region Settings
protected:
	/** * 이 구역에 적용할 기본 로직
	 * 예: Logic_CleanStain (얼룩 닦기), Logic_ExtinguishFire (불 끄기)
	 */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	TObjectPtr<UInteractionLogic> AssignedLogic;

	/** 작업 완료 후 이 액터를 파괴할지 여부 (얼룩 등은 닦으면 사라져야 함) */
	UPROPERTY(EditAnywhere, BlueprintReadOnly, Category = "Config")
	bool bDestroyOnComplete;
#pragma endregion

#pragma region Event Handlers
protected:
	/** TargetComponent의 진행률 변경 시 호출 (UI 업데이트) */
	UFUNCTION()
	void HandleProgressChanged(float NewProgress, bool bIsActive);

	/** TargetComponent의 작업 완료 시 호출 */
	UFUNCTION()
	void HandleInteractionCompleted(ACharacter* Completer, UInteractionLogic* Logic);
#pragma endregion
};