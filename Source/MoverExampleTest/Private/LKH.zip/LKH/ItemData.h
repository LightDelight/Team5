// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "Engine/DataAsset.h"
#include "GameplayTagContainer.h"
#include "ItemData.generated.h"

class UStaticMesh;
class UTexture2D;
class USoundBase;
class UInteractionLogic; // 전방 선언 (추후 구현 예정)

/**
 * 아이템을 잡았을 때의 손 모양 (보완계획서 5-C)
 */
UENUM(BlueprintType)
enum class EItemGripType : uint8
{
	None        UMETA(DisplayName = "None"),
	Fist        UMETA(DisplayName = "Fist (Power Grip)"),    // 꽉 쥐기 (망치, 칼)
	Palm        UMETA(DisplayName = "Palm (Open Hand)"),     // 손바닥 받치기 (접시, 수박)
	Pinch       UMETA(DisplayName = "Pinch (Two Fingers)"),  // 집게 손가락 (작은 열쇠, 카드)
	TwoHands    UMETA(DisplayName = "Two Hands")             // 양손 들기 (거대 박스)
};

/**
 * [설계서 제2기둥] 아이템의 정체성(Identity)을 정의하는 데이터 에셋
 * * 물리적 속성, 가격, 시각적 리소스, 사운드, 그리고 상호작용 규칙을 포함합니다.
 * 기획자는 이 에셋을 생성하여 '사과', '망치', '접시' 등을 정의합니다.
 */
UCLASS(BlueprintType)
class UItemData : public UPrimaryDataAsset
{
	GENERATED_BODY()

public:
	UItemData();

	/** 에셋 매니저 식별을 위한 오버라이드 */
	virtual FPrimaryAssetId GetPrimaryAssetId() const override;

#pragma region Identity & Economy
public:
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Identity")
	FText ItemName;

	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Identity", meta = (MultiLine = true))
	FText Description;

	/** 상점 구매 가격 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Identity", meta = (ClampMin = "0"))
	int32 Price;

	/** UI 표시용 아이콘 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "1. Identity")
	TObjectPtr<UTexture2D> Icon;
#pragma endregion

#pragma region Visuals & Physics
public:
	/** 인게임에서 보여질 실제 메쉬 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Visuals")
	TObjectPtr<UStaticMesh> StaticMesh;

	/** * 아이템 무게 (kg 단위)
	 * - 물리 시뮬레이션의 질량으로 사용됨
	 * - 플레이어의 이동 속도(Carry Speed)에 영향을 줌
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Visuals", meta = (ClampMin = "0.1"))
	float Weight;

	/** * 물리 재질 오버라이드 (선택 사항)
	 * - 바닥에 떨어졌을 때의 튀어오름(Bounciness), 마찰력 등 결정
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "2. Visuals")
	TObjectPtr<UPhysicalMaterial> PhysicsMaterial;
#pragma endregion

#pragma region Gameplay & Tags
public:
	/**
	 * [설계서 제3기둥] 부여 태그
	 * 이 아이템을 들었을 때 플레이어에게 부여되는 태그입니다.
	 * 예: Tool.Knife (칼을 들면 썰기 가능), Item.Ingredient.Onion (양파)
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "3. Gameplay")
	FGameplayTagContainer GrantedTags;

	/**
	 * [연결고리] 
	 * 이 아이템 자체가 상호작용의 대상(Interactable)일 경우 사용할 로직.
	 * 예: '더러운 접시' 아이템 -> '설거지 로직(Logic_Wash)' 연결.
	 * 일반 식재료는 비워둡니다.
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "3. Gameplay")
	TObjectPtr<UInteractionLogic> DefaultInteractionLogic;
#pragma endregion

#pragma region Grip & Animation (보완계획서)
public:
	/**
	 * 잡는 위치 소켓 이름
	 * - StaticMesh에 미리 정의된 소켓 이름을 입력 (예: "GripPoint")
	 * - 비워둘 경우 메쉬의 정중앙(Center)을 잡음
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "4. Grip Data")
	FName GripSocketName;

	/** 잡았을 때의 손 모양 및 자세 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "4. Grip Data")
	EItemGripType GripType;
#pragma endregion

#pragma region Audio (데이터 통합)
public:
	/** 집을 때 재생할 소리 (Pick Up) */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "5. Audio")
	TObjectPtr<USoundBase> Sound_Pickup;

	/** 놓거나 던질 때 재생할 소리 (Drop/Throw) */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "5. Audio")
	TObjectPtr<USoundBase> Sound_Drop;

	/** * 바닥/벽 충돌 시 소리 (Impact)
	 * - 물리적 충돌(Hit) 이벤트 발생 시 속도에 비례하여 재생
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "5. Audio")
	TObjectPtr<USoundBase> Sound_Collision;
#pragma endregion
};