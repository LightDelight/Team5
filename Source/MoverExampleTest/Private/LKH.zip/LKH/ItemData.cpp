#include "ItemData.h"

UItemData::UItemData()
{
	Price = 0;
	Weight = 1.0f;
	GripSocketName = FName("GripPoint"); // 기본 소켓 이름
	GripType = EItemGripType::Fist;
}

FPrimaryAssetId UItemData::GetPrimaryAssetId() const
{
	// 에셋 매니저에서 "ItemData" 타입으로 식별되도록 설정
	// 예: ItemData:Apple, ItemData:Hammer
	return FPrimaryAssetId(TEXT("ItemData"), GetFName());
}