// Fill out your copyright notice in the Description page of Project Settings.

#pragma once

#include "CoreMinimal.h"
#include "GameFramework/Actor.h"
#include "ItemSlotInterface.h"
#include "WorkstationBase.generated.h"

class UStaticMeshComponent;
class USceneComponent;
class UWidgetComponent;
class UInteractableTargetComponent;
class AItemBase;
class UInteractionLogic;
class UItemData;

/**
 * [설계서 제3기둥 & 제4기둥] 작업대 베이스
 * - 물류(Carry)와 작업(Interact)이 만나는 교차점입니다.
 * - 아이템을 올려두면(Slot), 해당 아이템의 특성에 맞춰 로직(Logic)을 스와핑합니다.
 */
UCLASS()
class AWorkstationBase : public AActor, public IItemSlotInterface
{
	GENERATED_BODY()

public:
	AWorkstationBase();

protected:
	virtual void BeginPlay() override;
	virtual void GetLifetimeReplicatedProps(TArray<FLifetimeProperty>& OutLifetimeProps) const override;

#pragma region Components
protected:
	/** 작업대 외형 메쉬 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UStaticMeshComponent> BodyMesh;

	/** * 아이템이 놓일 위치 (Anchor)
	 * - 아이템은 이 컴포넌트의 자식으로 Attach 됩니다.
	 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<USceneComponent> ItemSlotPoint;

	/** [두뇌] 실제 작업 진행도 관리 및 로직 실행 */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UInteractableTargetComponent> InteractableTarget;

	/** [UI] 작업 진행바 (TargetComponent와 연동) */
	UPROPERTY(VisibleAnywhere, BlueprintReadOnly, Category = "Components")
	TObjectPtr<UWidgetComponent> ProgressWidget;
#pragma endregion

#pragma region State & Logic
protected:
	/**
	 * 현재 슬롯에 올려진 아이템 (Replicated)
	 * - RepNotify를 통해 클라이언트에서도 시각적 부착(Attach)을 수행합니다.
	 */
	UPROPERTY(VisibleInstanceOnly, BlueprintReadOnly, ReplicatedUsing = OnRep_StoredItem, Category = "State")
	TObjectPtr<AItemBase> StoredItem;

	/**
	 * 비어있을 때 적용할 기본 로직
	 * 예: Logic_Null (상호작용 불가)
	 */
	UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	TObjectPtr<UInteractionLogic> EmptyLogic;

	/**
	 * [설계서 4-A] 조합 레시피 테이블 (선택 사항)
	 * - RowStruct: FItemRecipe (Ingredients, ResultItem)
	 */
	 // UPROPERTY(EditDefaultsOnly, BlueprintReadOnly, Category = "Config")
	 // TObjectPtr<UDataTable> RecipeTable; 

public:
	/** [핵심] 현재 상태에 맞춰 TargetComponent의 로직 교체 */
	UFUNCTION(BlueprintCallable, Category = "Logic")
	void RefreshInteractionLogic();

protected:
	UFUNCTION()
	void OnRep_StoredItem();

	/** TargetComponent의 UI 델리게이트 핸들러 */
	UFUNCTION()
	void HandleProgressChanged(float NewProgress, bool bIsActive);
#pragma endregion

#pragma region IItemSlotInterface Implementation
public:
	// 물건 놓기 (Put / Combine / Swap)
	virtual bool TryPutItem_Implementation(ACharacter* User, AItemBase* IncomingItem) override;

	// 물건 가져오기 (Take)
	virtual AItemBase* TryTakeItem_Implementation(ACharacter* User) override;

	virtual AItemBase* GetSlottedItem_Implementation() const override { return StoredItem; }
	virtual bool IsSlotEmpty_Implementation() const override { return StoredItem == nullptr; }
#pragma endregion

#pragma region Helpers
private:
	/** 두 아이템을 조합할 수 있는지 검사 (추후 DT 연동) */
	UItemData* FindCombinationResult(UItemData* ItemA, UItemData* ItemB) const;

	/** 조합 성공 처리 */
	void ProcessCombination(AItemBase* Existing, AItemBase* Incoming);
#pragma endregion
};